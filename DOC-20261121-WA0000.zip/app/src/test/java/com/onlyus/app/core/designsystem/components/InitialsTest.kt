package com.onlyus.app.core.designsystem.components

import org.junit.Assert.assertEquals
import org.junit.Test

/** The letters inside an avatar. Non-ASCII text is written as \u escapes so the file reads the same on any machine. */
class InitialsTest {

    @Test
    fun usesTheFirstLetterOfTheFirstAndLastWord() {
        assertEquals("SR", initialsOf("Sam Rivera"))
        assertEquals("JL", initialsOf("Jordan Lee"))
    }

    @Test
    fun capitalises() {
        assertEquals("SR", initialsOf("sam rivera"))
    }

    @Test
    fun aSingleWordGivesOneLetter() {
        assertEquals("S", initialsOf("sam"))
    }

    @Test
    fun middleNamesAreSkipped() {
        assertEquals("MW", initialsOf("Mary Jane Watson"))
    }

    @Test
    fun aHyphenatedNameIsOneWord() {
        assertEquals("AS", initialsOf("Anne-Marie Smith"))
    }

    @Test
    fun emptyAndBlankNamesGiveNothing() {
        assertEquals("", initialsOf(""))
        assertEquals("", initialsOf("   "))
        assertEquals("", initialsOf("\t\n"))
    }

    @Test
    fun extraWhitespaceIsIgnored() {
        assertEquals("SR", initialsOf("  Sam   Rivera  "))
        assertEquals("SR", initialsOf("Sam\tRivera"))
        assertEquals("SR", initialsOf("Sam\nRivera"))
    }

    @Test
    fun aNonBreakingSpaceSeparatesWordsToo() {
        // Names pasted from other apps often use U+00A0 instead of a normal space.
        assertEquals("SR", initialsOf("Sam Rivera"))
    }

    @Test
    fun accentedLettersAreKeptAndCapitalised() {
        // "élodie ñuñez"
        assertEquals("ÉÑ", initialsOf("élodie ñuñez"))
    }

    @Test
    fun anEmojiIsNeverCutInHalf() {
        // U+1F600 is one character stored as two UTF-16 units; taking only the first unit would leave a broken symbol.
        val result = initialsOf("😀 Sam")
        assertEquals("😀S", result)
        assertEquals(2, result.codePointCount(0, result.length))
    }

    @Test
    fun otherScriptsWork() {
        // Two Devanagari words; the result is the first character of each.
        assertEquals("अश", initialsOf("अनु शर्मा"))
    }
}
