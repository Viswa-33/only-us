package com.onlyus.app.core.designsystem.theme

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The one rule that turns "what the user chose" plus "what the device says" into how much polish the UI shows. */
class EffectsPolicyTest {

    private val healthyDevice = PerformanceHints()

    @Test
    fun reducedMode_alwaysReducesEffects_whateverTheDeviceSays() {
        assertTrue(resolveEffects(EffectsMode.REDUCED, healthyDevice).reducedEffects)
        assertTrue(
            resolveEffects(EffectsMode.REDUCED, PerformanceHints(lowRamDevice = true, batterySaver = true)).reducedEffects,
        )
    }

    @Test
    fun fullMode_neverReducesEffects_evenOnAWeakDevice() {
        assertFalse(resolveEffects(EffectsMode.FULL, healthyDevice).reducedEffects)
        val weakDevice = PerformanceHints(lowRamDevice = true, batterySaver = true, animationsDisabled = true)
        assertFalse(resolveEffects(EffectsMode.FULL, weakDevice).reducedEffects)
    }

    @Test
    fun autoMode_keepsFullEffects_onAHealthyDevice() {
        assertFalse(resolveEffects(EffectsMode.AUTO, healthyDevice).reducedEffects)
    }

    @Test
    fun autoMode_reducesEffects_onALowMemoryDevice() {
        assertTrue(resolveEffects(EffectsMode.AUTO, PerformanceHints(lowRamDevice = true)).reducedEffects)
    }

    @Test
    fun autoMode_reducesEffects_whenBatterySaverIsOn() {
        assertTrue(resolveEffects(EffectsMode.AUTO, PerformanceHints(batterySaver = true)).reducedEffects)
    }

    @Test
    fun autoMode_reducesEffects_whenBothApply() {
        val hints = PerformanceHints(lowRamDevice = true, batterySaver = true)
        assertTrue(resolveEffects(EffectsMode.AUTO, hints).reducedEffects)
    }

    @Test
    fun autoMode_doesNotFlattenTheGlass_justBecauseAnimationsAreOff() {
        // Turning system animations off is a motion preference, not a performance problem.
        val result = resolveEffects(EffectsMode.AUTO, PerformanceHints(animationsDisabled = true))
        assertFalse(result.reducedEffects)
        assertTrue(result.reducedMotion)
    }

    @Test
    fun reducedMotion_followsTheSystemAnimationSetting_inEveryMode() {
        for (mode in EffectsMode.entries) {
            assertTrue("$mode", resolveEffects(mode, PerformanceHints(animationsDisabled = true)).reducedMotion)
            assertFalse("$mode", resolveEffects(mode, PerformanceHints(animationsDisabled = false)).reducedMotion)
        }
    }

    @Test
    fun wholeMatrix_matchesTheWrittenRule() {
        // 3 modes x 8 combinations of device facts: pins the rule so that changing it has to be deliberate.
        val both = listOf(false, true)
        for (mode in EffectsMode.entries) {
            for (lowRam in both) {
                for (saver in both) {
                    for (animationsOff in both) {
                        val expectedReduced = when (mode) {
                            EffectsMode.REDUCED -> true
                            EffectsMode.FULL -> false
                            EffectsMode.AUTO -> lowRam || saver
                        }
                        val label = "mode=$mode lowRam=$lowRam saver=$saver animationsOff=$animationsOff"
                        assertEquals(
                            label,
                            OnlyUsEffects(reducedEffects = expectedReduced, reducedMotion = animationsOff),
                            resolveEffects(mode, PerformanceHints(lowRam, saver, animationsOff)),
                        )
                    }
                }
            }
        }
    }

    @Test
    fun fullPreset_isFullPolishWithNormalMotion() {
        assertEquals(OnlyUsEffects(reducedEffects = false, reducedMotion = false), OnlyUsEffects.Full)
    }

    @Test
    fun defaultHints_describeAHealthyDevice() {
        assertEquals(PerformanceHints(lowRamDevice = false, batterySaver = false, animationsDisabled = false), healthyDevice)
    }
}
