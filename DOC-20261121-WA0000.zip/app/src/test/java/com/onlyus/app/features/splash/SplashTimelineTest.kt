package com.onlyus.app.features.splash

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** The splash choreography is plain numbers (one progress value from 0 to 1), so its rules can be checked exactly. */
class SplashTimelineTest {

    private val eps = 1e-5f

    private val story = listOf(
        "Emblem" to SplashTimeline.Emblem,
        "Hearts" to SplashTimeline.Hearts,
        "Wordmark" to SplashTimeline.Wordmark,
        "Ornament" to SplashTimeline.Ornament,
        "TaglineFirst" to SplashTimeline.TaglineFirst,
        "TaglineSecond" to SplashTimeline.TaglineSecond,
    )

    /** 0, 1/steps, 2/steps ... 1, each computed as an exact fraction instead of an accumulated sum. */
    private fun sweep(steps: Int = 400): List<Float> = (0..steps).map { it / steps.toFloat() }

    // ---- segment -------------------------------------------------------------------------------------------------

    @Test
    fun segment_isZeroBeforeItsWindow() {
        val window = Window(0.3f, 0.6f)
        assertEquals(0f, segment(0f, window), 0f)
        assertEquals(0f, segment(0.29f, window), 0f)
        assertEquals(0f, segment(-5f, window), 0f)
    }

    @Test
    fun segment_isOneAfterItsWindow() {
        val window = Window(0.3f, 0.6f)
        assertEquals(1f, segment(0.61f, window), 0f)
        assertEquals(1f, segment(1f, window), 0f)
        assertEquals(1f, segment(7f, window), 0f)
    }

    @Test
    fun segment_runsLinearlyInsideItsWindow() {
        val window = Window(0.3f, 0.6f)
        assertEquals(0.0f, segment(0.30f, window), eps)
        assertEquals(0.5f, segment(0.45f, window), eps)
        assertEquals(1.0f, segment(0.60f, window), eps)
    }

    @Test
    fun segment_neverLeavesZeroToOne_forAnyWindowOfTheStory() {
        for ((name, window) in story) {
            for (progress in sweep()) {
                val value = segment(progress, window)
                assertTrue("$name at $progress gave $value", value in 0f..1f)
            }
        }
    }

    @Test
    fun segment_neverMovesBackwards() {
        for ((name, window) in story) {
            var previous = 0f
            for (progress in sweep()) {
                val value = segment(progress, window)
                assertTrue("$name went backwards at $progress", value >= previous)
                previous = value
            }
        }
    }

    @Test
    fun segment_ofAWindowWithNoLength_jumpsFromZeroToOne() {
        val window = Window(0.5f, 0.5f)
        assertEquals(0f, segment(0.49f, window), 0f)
        assertEquals(1f, segment(0.5f, window), 0f)
        assertEquals(1f, segment(0.9f, window), 0f)
    }

    @Test
    fun segment_ofABackwardsWindow_stillStaysBetweenZeroAndOne() {
        val window = Window(0.6f, 0.4f)
        for (progress in sweep()) {
            val value = segment(progress, window)
            assertTrue("backwards window at $progress gave $value", value in 0f..1f)
        }
    }

    // ---- easeOutCubic --------------------------------------------------------------------------------------------

    @Test
    fun easeOutCubic_startsAtZeroAndEndsAtOne() {
        assertEquals(0f, easeOutCubic(0f), 0f)
        assertEquals(1f, easeOutCubic(1f), 0f)
    }

    @Test
    fun easeOutCubic_holdsItsEndsForOutOfRangeInput() {
        assertEquals(0f, easeOutCubic(-3f), 0f)
        assertEquals(1f, easeOutCubic(7f), 0f)
    }

    @Test
    fun easeOutCubic_hasTheExpectedMidpoint() {
        // 1 - (1 - 0.5)^3 = 0.875: already most of the way there at the halfway mark.
        assertEquals(0.875f, easeOutCubic(0.5f), eps)
    }

    @Test
    fun easeOutCubic_neverMovesBackwards() {
        var previous = 0f
        for (t in sweep(1000)) {
            val value = easeOutCubic(t)
            assertTrue("went backwards at $t", value >= previous)
            previous = value
        }
    }

    @Test
    fun easeOutCubic_arrivesFastAndSettlesGently() {
        assertTrue("fast start", easeOutCubic(0.1f) > 0.2f) // linear motion would only be at 0.1 here
        assertTrue("gentle finish", easeOutCubic(1f) - easeOutCubic(0.9f) < 0.01f)
    }

    // ---- the story -----------------------------------------------------------------------------------------------

    @Test
    fun everyWindowFitsInsideTheTimelineAndHasALength() {
        for ((name, window) in story) {
            assertTrue("$name starts at or after 0", window.start >= 0f)
            assertTrue("$name ends at or before 1", window.end <= 1f)
            assertTrue("$name has a length", window.start < window.end)
        }
    }

    @Test
    fun theStoryIsToldInOrder() {
        // Emblem, then wordmark, then ornament, then the first and the second tagline line.
        val starts = listOf(
            SplashTimeline.Emblem,
            SplashTimeline.Wordmark,
            SplashTimeline.Ornament,
            SplashTimeline.TaglineFirst,
            SplashTimeline.TaglineSecond,
        ).map { it.start }
        assertTrue("starts should strictly increase: $starts", starts.zipWithNext().all { (a, b) -> a < b })
    }

    @Test
    fun theTaglineIsCompleteBeforeTheAnimationEnds_soTheFinishedSplashIsHeldBriefly() {
        assertTrue(SplashTimeline.TaglineSecond.end < 1f)
    }

    @Test
    fun durationsMakeSense() {
        assertTrue(SplashTimeline.ReducedDurationMillis > 0)
        assertTrue(SplashTimeline.ReducedDurationMillis < SplashTimeline.FullDurationMillis)
        assertTrue("a greeting, not a wait", SplashTimeline.FullDurationMillis <= 3000)
        assertTrue(SplashTimeline.StaticHoldMillis > 0L)
    }

    // ---- the floating hearts -------------------------------------------------------------------------------------

    @Test
    fun thereAreSevenHearts() {
        assertEquals(7, SplashHearts.size)
    }

    @Test
    fun everyHeartIsDescribedSensibly() {
        for ((index, heart) in SplashHearts.withIndex()) {
            val label = "heart #$index"
            assertTrue("$label x", heart.x in 0f..1f)
            assertTrue("$label size", heart.sizeDp > 0f)
            assertTrue("$label rise", heart.rise > 0f)
            assertTrue("$label opacity", heart.peakAlpha > 0f && heart.peakAlpha <= 1f)
            // The theme provides four heart colours in both light and dark.
            assertTrue("$label colour", heart.colorIndex in 0..3)
            assertTrue("$label window", heart.window.start >= 0f && heart.window.end <= 1f && heart.window.start < heart.window.end)
        }
    }

    @Test
    fun noHeartIsVisibleAtTheVeryStartOrTheVeryEnd() {
        for ((index, heart) in SplashHearts.withIndex()) {
            assertEquals("start of heart #$index", 0f, heart.frameAt(0f).alpha, 1e-6f)
            assertEquals("end of heart #$index", 0f, heart.frameAt(1f).alpha, 1e-6f)
        }
    }

    @Test
    fun aHeartFadesInAndOut_zeroAtBothEndsOfItsWindowAndStrongestInTheMiddle() {
        for ((index, heart) in SplashHearts.withIndex()) {
            val window = heart.window
            assertEquals("window start of #$index", 0f, heart.frameAt(window.start).alpha, 1e-6f)
            assertEquals("window end of #$index", 0f, heart.frameAt(window.end).alpha, 1e-6f)
            val middle = (window.start + window.end) / 2f
            assertEquals("middle of #$index", heart.peakAlpha, heart.frameAt(middle).alpha, 1e-4f)
        }
    }

    @Test
    fun aHeartIsExactlyInvisibleOutsideItsWindow() {
        for ((index, heart) in SplashHearts.withIndex()) {
            for (progress in sweep()) {
                if (progress < heart.window.start || progress > heart.window.end) {
                    assertEquals("heart #$index at $progress", 0f, heart.frameAt(progress).alpha, 0f)
                }
            }
        }
    }

    @Test
    fun opacityStaysBetweenZeroAndThePeak() {
        for ((index, heart) in SplashHearts.withIndex()) {
            for (progress in sweep()) {
                val alpha = heart.frameAt(progress).alpha
                assertTrue("heart #$index at $progress is below zero: $alpha", alpha >= 0f)
                assertTrue("heart #$index at $progress is above its peak: $alpha", alpha <= heart.peakAlpha + eps)
            }
        }
    }

    @Test
    fun heartsNeverLeaveTheScreen() {
        for ((index, heart) in SplashHearts.withIndex()) {
            for (progress in sweep()) {
                val frame = heart.frameAt(progress)
                assertTrue("heart #$index x at $progress: ${frame.x}", frame.x in 0f..1f)
                assertTrue("heart #$index y at $progress: ${frame.y}", frame.y in 0f..1f)
            }
        }
    }

    @Test
    fun heartsOnlyEverRise() {
        for ((index, heart) in SplashHearts.withIndex()) {
            var previous = heart.frameAt(0f).y
            for (progress in sweep()) {
                val y = heart.frameAt(progress).y
                assertTrue("heart #$index sank at $progress", y <= previous + 1e-6f)
                previous = y
            }
        }
    }

    @Test
    fun aHeartTravelsItsFullRiseAndTurnsByItsTilt() {
        for ((index, heart) in SplashHearts.withIndex()) {
            val first = heart.frameAt(heart.window.start)
            val last = heart.frameAt(heart.window.end)
            assertEquals("rise of #$index", heart.rise, first.y - last.y, eps)
            assertEquals("turn of #$index at the start", 0f, first.rotation, eps)
            assertEquals("turn of #$index at the end", heart.tilt, last.rotation, eps)
        }
    }
}
