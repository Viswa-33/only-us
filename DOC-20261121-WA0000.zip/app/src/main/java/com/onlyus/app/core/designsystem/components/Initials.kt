package com.onlyus.app.core.designsystem.components

// Any run of whitespace or Unicode separators. \p{Z} is what catches the non-breaking space that names pasted from
// other apps often contain, which plain \s does not.
private val NameSeparator = Regex("[\\s\\p{Z}]+")

/**
 * The letters shown in an avatar: the first letter of the first word and of the last word of a name, capitalised.
 *
 *  - "Sam Rivera" becomes "SR", "Mary Jane Watson" becomes "MW", "sam" becomes "S", and an empty name becomes "".
 *
 * It works on whole characters (code points), so a name that begins with an emoji or a rarer script is never cut in
 * half. Plain Kotlin with no Android or Compose imports, so it is unit-tested directly.
 */
fun initialsOf(name: String): String {
    val words = name.split(NameSeparator).filter { it.isNotEmpty() }
    if (words.isEmpty()) return ""
    val picked = if (words.size == 1) listOf(words.first()) else listOf(words.first(), words.last())
    return picked.joinToString("") { word -> String(Character.toChars(word.codePointAt(0))) }.uppercase()
}
