package com.onlyus.app.core.designsystem.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.theme.OnlyUsMotion
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

/**
 * A small rose pill with an unread count. It pops in with a soft spring, hides when the count is zero, and the number
 * slides when it changes. With reduced motion it simply appears. It announces itself as "N unread notifications".
 */
@Composable
fun NotificationBadge(
    count: Int,
    modifier: Modifier = Modifier,
    maxCount: Int = 99,
) {
    val scheme = MaterialTheme.colorScheme
    val animate = !OnlyUsTheme.effects.reducedMotion
    val visible = count > 0

    // While the badge shrinks away it keeps showing the last real number instead of flashing "0".
    val lastPositive = remember { mutableIntStateOf(count) }
    SideEffect { if (count > 0) lastPositive.intValue = count }
    val shown = if (visible) count else lastPositive.intValue

    val scale = animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = if (animate) {
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)
        } else {
            snap()
        },
        label = "badgeScale",
    )
    val description = pluralStringResource(R.plurals.badge_unread, count, count)

    Box(
        modifier = modifier
            .graphicsLayer {
                val s = scale.value
                scaleX = s
                scaleY = s
                alpha = s.coerceIn(0f, 1f)
            }
            // One spoken description for the whole pill, and nothing at all while it is hidden.
            .clearAndSetSemantics { if (visible) contentDescription = description }
            .defaultMinSize(minWidth = 18.dp, minHeight = 18.dp)
            .background(scheme.tertiary, CircleShape)
            .border(1.5.dp, scheme.background, CircleShape)
            .padding(horizontal = 5.dp),
        contentAlignment = Alignment.Center,
    ) {
        val label = if (shown > maxCount) "$maxCount+" else shown.toString()
        if (animate) {
            AnimatedContent(
                targetState = label,
                transitionSpec = {
                    (slideInVertically(tween(OnlyUsMotion.Short)) { it } + fadeIn(tween(OnlyUsMotion.Short))) togetherWith
                        (slideOutVertically(tween(OnlyUsMotion.Short)) { -it } + fadeOut(tween(100)))
                },
                label = "badgeCount",
            ) { text ->
                Text(text = text, style = MaterialTheme.typography.labelSmall, color = scheme.onTertiary, maxLines = 1)
            }
        } else {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = scheme.onTertiary, maxLines = 1)
        }
    }
}

/**
 * The Only Us loader: a heart that beats, with a faint ring that echoes each beat.
 * The beat only runs while [animating] is true and the system allows motion. Otherwise it is a still heart.
 * It reads the animation while drawing, so it never recomposes. Leave [color] unspecified for the brand gradient.
 */
@Composable
fun OnlyUsLoadingIndicator(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    animating: Boolean = true,
    color: Color = Color.Unspecified,
) {
    val brand = OnlyUsTheme.brand
    val run = animating && !OnlyUsTheme.effects.reducedMotion
    val label = stringResource(R.string.loading)

    val pulse: State<Float> = if (run) {
        rememberInfiniteTransition(label = "heartbeat").animateFloat(
            initialValue = 0.90f,
            targetValue = 0.90f,
            animationSpec = infiniteRepeatable(
                animation = keyframes {
                    durationMillis = 1300
                    0.90f at 0
                    1.12f at 220 using FastOutSlowInEasing
                    0.96f at 420 using FastOutSlowInEasing
                    1.06f at 620 using FastOutSlowInEasing
                    0.90f at 900 using FastOutSlowInEasing
                    0.90f at 1300
                },
                repeatMode = RepeatMode.Restart,
            ),
            label = "heartbeatScale",
        )
    } else {
        remember { mutableFloatStateOf(1f) }
    }

    Canvas(
        modifier = modifier
            .size(size)
            .semantics {
                contentDescription = label
                progressBarRangeInfo = ProgressBarRangeInfo.Indeterminate
            },
    ) {
        val scale = pulse.value
        val side = this.size.minDimension
        val heartSize = side * 0.74f * scale
        if (color == Color.Unspecified) {
            drawHeart(brush = brand.heartBurgundyBrush, center = center, size = heartSize)
        } else {
            drawHeart(color = color, center = center, size = heartSize)
        }
        if (run) {
            val echo = ((scale - 0.90f) / 0.22f).coerceIn(0f, 1f)
            drawCircle(
                color = if (color == Color.Unspecified) brand.roseGold else color,
                radius = side * 0.5f * (0.78f + 0.22f * echo),
                center = center,
                alpha = 0.35f * echo,
                style = Stroke(width = 1.5.dp.toPx()),
            )
        }
    }
}

/** Text that cross-fades when its content changes, so a label or status line never just snaps. */
@Composable
fun AnimatedText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    textAlign: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE,
) {
    if (OnlyUsTheme.effects.reducedMotion) {
        Text(text = text, modifier = modifier, color = color, style = style, textAlign = textAlign, maxLines = maxLines)
    } else {
        AnimatedContent(
            targetState = text,
            modifier = modifier,
            transitionSpec = { fadeIn(tween(OnlyUsMotion.Short, delayMillis = 90)) togetherWith fadeOut(tween(90)) },
            label = "animatedText",
        ) { value ->
            Text(text = value, color = color, style = style, textAlign = textAlign, maxLines = maxLines)
        }
    }
}
