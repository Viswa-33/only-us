package com.onlyus.app.core.designsystem.theme

/** How much visual polish the user wants. AUTO lets the device decide. */
enum class EffectsMode { AUTO, FULL, REDUCED }

/** Facts about the device that decide whether AUTO should reduce effects. Pure data, easy to test. */
data class PerformanceHints(
    val lowRamDevice: Boolean = false,
    val batterySaver: Boolean = false,
    val animationsDisabled: Boolean = false,
)

/**
 * What the UI actually does right now.
 *
 * reducedEffects: flat themed surfaces, no shadows, no sheen, no background orbs, no floating hearts.
 * reducedMotion: the system animation scale is 0, so non-essential animation is skipped.
 */
data class OnlyUsEffects(
    val reducedEffects: Boolean,
    val reducedMotion: Boolean,
) {
    companion object {
        val Full = OnlyUsEffects(reducedEffects = false, reducedMotion = false)
    }
}

/** The one rule that turns a user choice plus device facts into the effects used by the UI. */
fun resolveEffects(mode: EffectsMode, hints: PerformanceHints): OnlyUsEffects {
    val reduced = when (mode) {
        EffectsMode.REDUCED -> true
        EffectsMode.FULL -> false
        EffectsMode.AUTO -> hints.lowRamDevice || hints.batterySaver
    }
    return OnlyUsEffects(reducedEffects = reduced, reducedMotion = hints.animationsDisabled)
}
