package com.onlyus.app.core.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.onlyus.app.core.designsystem.theme.EffectsMode
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

/** Which colour scheme the user wants. SYSTEM follows the phone's light or dark setting. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Everything the app remembers about how the user wants it to look, plus whether onboarding has been seen. */
data class AppPreferences(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val effectsMode: EffectsMode = EffectsMode.AUTO,
    val onboardingCompleted: Boolean = false,
)

/**
 * The single place that reads and writes those settings, backed by Preferences DataStore.
 * Nothing here is personal data, and none of it leaves the device.
 */
@Singleton
class AppPreferencesRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>,
) {
    val preferences: Flow<AppPreferences> = dataStore.data
        .catch { error ->
            // An unreadable file means "use the defaults", never a crash. Anything else is a real bug.
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { stored ->
            AppPreferences(
                themeMode = stored[Keys.ThemeMode].toEnumOrDefault(ThemeMode.SYSTEM),
                effectsMode = stored[Keys.EffectsMode].toEnumOrDefault(EffectsMode.AUTO),
                onboardingCompleted = stored[Keys.OnboardingCompleted] ?: false,
            )
        }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[Keys.ThemeMode] = mode.name }
    }

    suspend fun setEffectsMode(mode: EffectsMode) {
        dataStore.edit { it[Keys.EffectsMode] = mode.name }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        dataStore.edit { it[Keys.OnboardingCompleted] = completed }
    }

    private object Keys {
        val ThemeMode = stringPreferencesKey("theme_mode")
        val EffectsMode = stringPreferencesKey("effects_mode")
        val OnboardingCompleted = booleanPreferencesKey("onboarding_completed")
    }
}

private inline fun <reified T : Enum<T>> String?.toEnumOrDefault(default: T): T =
    enumValues<T>().firstOrNull { it.name == this } ?: default
