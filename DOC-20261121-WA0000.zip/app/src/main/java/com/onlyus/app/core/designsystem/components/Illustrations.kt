package com.onlyus.app.core.designsystem.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.onlyus.app.core.designsystem.theme.BrandColors
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

/*
 * Three small illustrations for empty states and onboarding, drawn in code from theme tokens, so they follow light and
 * dark mode and need no image files. Each is drawn in a 180 x 140 design space that scales to the requested width.
 * They are decorative: the title and text next to them carry the meaning, so they are hidden from screen readers.
 */

private const val DesignWidth = 180f
private const val DesignHeight = 140f

@Composable
private fun IllustrationCanvas(modifier: Modifier, width: Dp, draw: DrawScope.() -> Unit) {
    Canvas(modifier.size(width, width * (DesignHeight / DesignWidth)).clearAndSetSemantics { }) {
        val k = this.size.width / DesignWidth
        withTransform({ scale(scaleX = k, scaleY = k, pivot = Offset.Zero) }) { draw() }
    }
}

private fun DrawScope.paperCard(topLeft: Offset, size: Size, radius: Float, paper: Color, edge: Color, shadow: Color) {
    drawRoundRect(color = shadow, topLeft = topLeft + Offset(0f, 3f), size = size, cornerRadius = CornerRadius(radius))
    drawRoundRect(color = paper, topLeft = topLeft, size = size, cornerRadius = CornerRadius(radius))
    drawRoundRect(color = edge, topLeft = topLeft, size = size, cornerRadius = CornerRadius(radius), style = Stroke(width = 1.2f))
}

private fun DrawScope.sparkles(brand: BrandColors) {
    drawHeart(color = brand.roseGold, center = Offset(150f, 34f), size = 11f, rotationDegrees = 14f, alpha = 0.85f)
    drawHeart(color = brand.roseGoldLight, center = Offset(30f, 100f), size = 9f, rotationDegrees = -16f, alpha = 0.9f)
    drawHeart(color = brand.roseGold, center = Offset(165f, 70f), size = 7f, rotationDegrees = 8f, alpha = 0.6f)
}

/** An open envelope with a blank sheet and a heart seal. For "no letters yet". */
@Composable
fun LetterIllustration(modifier: Modifier = Modifier, width: Dp = 180.dp) {
    val scheme = MaterialTheme.colorScheme
    val brand = OnlyUsTheme.brand
    val glass = OnlyUsTheme.glass

    IllustrationCanvas(modifier, width) {
        drawCircle(color = brand.illustrationBackdrop, radius = 60f, center = Offset(90f, 72f))
        sparkles(brand)

        val flap = Path().apply {
            moveTo(40f, 60f)
            lineTo(90f, 22f)
            lineTo(140f, 60f)
            close()
        }
        drawPath(path = flap, color = scheme.surfaceContainerHigh)
        drawPath(path = flap, color = brand.roseGold, style = Stroke(width = 1.5f, join = StrokeJoin.Round))

        paperCard(Offset(55f, 34f), Size(70f, 60f), 6f, scheme.surface, scheme.outlineVariant, glass.shadow)
        for (i in 0..1) {
            val y = 45f + i * 9f
            drawLine(
                color = brand.roseGold.copy(alpha = 0.55f),
                start = Offset(65f, y),
                end = Offset(if (i == 1) 95f else 115f, y),
                strokeWidth = 2.5f,
                cap = StrokeCap.Round,
            )
        }

        paperCard(Offset(38f, 60f), Size(104f, 58f), 10f, scheme.surface, brand.roseGold, glass.shadow)
        val pocket = Path().apply {
            moveTo(42f, 65f)
            lineTo(90f, 99f)
            lineTo(138f, 65f)
        }
        drawPath(path = pocket, color = brand.roseGold, style = Stroke(width = 1.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawHeart(brush = brand.heartBurgundyBrush, center = Offset(90f, 96f), size = 20f)
    }
}

/** Two speech bubbles, one holding a heart. For "no messages yet" and for the onboarding page about staying close. */
@Composable
fun ChatIllustration(modifier: Modifier = Modifier, width: Dp = 180.dp) {
    val scheme = MaterialTheme.colorScheme
    val brand = OnlyUsTheme.brand
    val glass = OnlyUsTheme.glass

    IllustrationCanvas(modifier, width) {
        drawCircle(color = brand.illustrationBackdrop, radius = 60f, center = Offset(90f, 72f))
        sparkles(brand)

        // Left bubble, with three typing dots. The tail is filled over the bubble's outline, then only its outer edges
        // are stroked, so the outline flows into the tail without a line across its mouth.
        val tailFill = Path().apply {
            moveTo(44f, 76f)
            lineTo(38f, 92f)
            lineTo(64f, 78f)
            close()
        }
        val tailEdge = Path().apply {
            moveTo(44.2f, 78f)
            lineTo(38f, 92f)
            lineTo(64f, 78f)
        }
        drawRoundRect(color = glass.shadow, topLeft = Offset(28f, 36f), size = Size(88f, 46f), cornerRadius = CornerRadius(16f))
        drawRoundRect(color = scheme.surface, topLeft = Offset(28f, 32f), size = Size(88f, 46f), cornerRadius = CornerRadius(16f))
        drawRoundRect(
            color = brand.roseGold,
            topLeft = Offset(28f, 32f),
            size = Size(88f, 46f),
            cornerRadius = CornerRadius(16f),
            style = Stroke(width = 1.2f),
        )
        drawPath(path = tailFill, color = scheme.surface)
        drawPath(path = tailEdge, color = brand.roseGold, style = Stroke(width = 1.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        for (i in 0..2) {
            drawCircle(color = brand.roseGold, radius = 3.2f, center = Offset(58f + i * 14f, 55f))
        }

        // Right bubble, burgundy, with a heart.
        val tailB = Path().apply {
            moveTo(136f, 112f)
            lineTo(146f, 130f)
            lineTo(120f, 116f)
            close()
        }
        // Gradients inside the illustration use explicit design-space coordinates, because the canvas is scaled.
        val burgundy = Brush.linearGradient(
            colors = listOf(brand.actionStart, brand.actionEnd),
            start = Offset(66f, 70f),
            end = Offset(156f, 116f),
        )
        drawRoundRect(color = glass.shadow, topLeft = Offset(66f, 74f), size = Size(90f, 46f), cornerRadius = CornerRadius(16f))
        drawRoundRect(brush = burgundy, topLeft = Offset(66f, 70f), size = Size(90f, 46f), cornerRadius = CornerRadius(16f))
        drawPath(path = tailB, brush = burgundy)
        drawHeart(color = brand.onAction, center = Offset(111f, 93f), size = 20f)
    }
}

/** Two tilted photo frames, the front one holding a heart. For "no memories yet". */
@Composable
fun PhotosIllustration(modifier: Modifier = Modifier, width: Dp = 180.dp) {
    val scheme = MaterialTheme.colorScheme
    val brand = OnlyUsTheme.brand
    val glass = OnlyUsTheme.glass

    IllustrationCanvas(modifier, width) {
        drawCircle(color = brand.illustrationBackdrop, radius = 60f, center = Offset(90f, 72f))
        sparkles(brand)

        // Back frame: a little landscape.
        withTransform({ rotate(degrees = -9f, pivot = Offset(72f, 78f)) }) {
            paperCard(Offset(42f, 36f), Size(60f, 76f), 5f, scheme.surface, scheme.outlineVariant, glass.shadow)
            drawRoundRect(color = scheme.primaryContainer, topLeft = Offset(47f, 41f), size = Size(50f, 50f), cornerRadius = CornerRadius(3f))
            val hills = Path().apply {
                moveTo(47f, 91f)
                lineTo(47f, 80f)
                lineTo(62f, 64f)
                lineTo(72f, 76f)
                lineTo(80f, 68f)
                lineTo(97f, 84f)
                lineTo(97f, 91f)
                close()
            }
            drawPath(path = hills, color = brand.roseGold.copy(alpha = 0.55f))
            drawCircle(color = brand.roseGold.copy(alpha = 0.75f), radius = 5f, center = Offset(86f, 53f))
        }

        // Front frame: a heart.
        withTransform({ rotate(degrees = 8f, pivot = Offset(112f, 82f)) }) {
            paperCard(Offset(82f, 42f), Size(62f, 78f), 5f, scheme.surface, brand.roseGold, glass.shadow)
            val burgundy = Brush.linearGradient(
                colors = listOf(brand.actionStart, brand.actionEnd),
                start = Offset(87f, 47f),
                end = Offset(139f, 99f),
            )
            drawRoundRect(brush = burgundy, topLeft = Offset(87f, 47f), size = Size(52f, 52f), cornerRadius = CornerRadius(3f))
            drawHeart(color = brand.onAction, center = Offset(113f, 73f), size = 24f)
            drawLine(
                color = brand.roseGold.copy(alpha = 0.55f),
                start = Offset(92f, 109f),
                end = Offset(124f, 109f),
                strokeWidth = 2.5f,
                cap = StrokeCap.Round,
            )
        }
    }
}
