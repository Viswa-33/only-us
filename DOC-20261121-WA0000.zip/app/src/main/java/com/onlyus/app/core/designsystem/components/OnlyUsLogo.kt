package com.onlyus.app.core.designsystem.components

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.theme.OnlyUsTextStyles
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

/**
 * The Only Us emblem: a glass disc holding two hearts, one rose gold and one burgundy.
 *
 * [together] runs from 0 to 1. At 0 the hearts are apart and invisible, at 1 they rest side by side.
 * It is a lambda so the animation is read while drawing: the emblem redraws, it never recomposes.
 */
@Composable
fun OnlyUsEmblem(
    modifier: Modifier = Modifier,
    size: Dp = 112.dp,
    together: () -> Float = { 1f },
) {
    val brand = OnlyUsTheme.brand
    val glass = OnlyUsTheme.glass
    val reduced = OnlyUsTheme.effects.reducedEffects

    Spacer(
        modifier
            .size(size)
            .drawWithCache {
                val s = this.size.minDimension
                val middle = Offset(this.size.width / 2f, this.size.height / 2f)
                val discRadius = s * 0.38f
                val ring = 1.dp.toPx()
                val halo = Brush.radialGradient(
                    colors = listOf(brand.halo, Color.Transparent),
                    center = middle,
                    radius = s * 0.5f,
                )
                val disc = Brush.verticalGradient(
                    colors = listOf(brand.logoDiscTop, brand.logoDiscBottom),
                    startY = middle.y - discRadius,
                    endY = middle.y + discRadius,
                )
                onDrawBehind {
                    val t = together().coerceIn(0f, 1f)
                    if (!reduced) drawCircle(brush = halo, radius = s * 0.5f, center = middle)
                    drawCircle(brush = disc, radius = discRadius, center = middle)
                    drawCircle(
                        brush = glass.border,
                        radius = discRadius - ring / 2f,
                        center = middle,
                        style = Stroke(width = ring),
                    )
                    // Rose-gold heart drifts in from the upper left, the burgundy one from the lower right.
                    drawHeart(
                        brush = brand.heartRoseGoldBrush,
                        center = Offset(lerp(0.30f, 0.446f, t) * s, lerp(0.38f, 0.478f, t) * s),
                        size = s * 0.41f,
                        rotationDegrees = lerp(-26f, -12f, t),
                        alpha = t,
                    )
                    drawHeart(
                        brush = brand.heartBurgundyBrush,
                        center = Offset(lerp(0.74f, 0.598f, t) * s, lerp(0.68f, 0.566f, t) * s),
                        size = s * 0.32f,
                        rotationDegrees = lerp(24f, 10f, t),
                        alpha = t,
                    )
                }
            },
    )
}

/**
 * "Only Us" in Playfair Display Italic with a burgundy-to-rose-gold gradient.
 * It is drawn at a fixed size, ignoring the system font scale: a logo must never reflow or clip.
 */
@Composable
fun OnlyUsWordmark(
    modifier: Modifier = Modifier,
    textStyle: TextStyle = OnlyUsTextStyles.Wordmark,
) {
    val brand = OnlyUsTheme.brand
    val fixedScale = Density(density = LocalDensity.current.density, fontScale = 1f)

    CompositionLocalProvider(LocalDensity provides fixedScale) {
        Text(
            text = stringResource(R.string.app_name),
            style = textStyle.copy(
                brush = Brush.horizontalGradient(listOf(brand.wordmarkStart, brand.wordmarkEnd)),
            ),
            modifier = modifier,
            maxLines = 1,
            softWrap = false,
        )
    }
}
