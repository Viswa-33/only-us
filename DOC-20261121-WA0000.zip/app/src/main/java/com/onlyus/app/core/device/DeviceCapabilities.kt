package com.onlyus.app.core.device

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import com.onlyus.app.core.designsystem.theme.PerformanceHints
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Watches the few device facts that decide whether effects should be reduced automatically:
 * a low-RAM device, Battery Saver, and the system "remove animations" setting.
 * It only listens while something collects the flow, and unregisters everything when collection stops.
 */
@Singleton
class DeviceCapabilities @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    val hints: Flow<PerformanceHints> = callbackFlow {
        val activityManager = context.getSystemService<ActivityManager>()
        val powerManager = context.getSystemService<PowerManager>()
        val resolver = context.contentResolver

        fun read() = PerformanceHints(
            lowRamDevice = activityManager?.isLowRamDevice == true,
            batterySaver = powerManager?.isPowerSaveMode == true,
            animationsDisabled = Settings.Global.getFloat(resolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f,
        )

        trySend(read())

        val powerReceiver = object : BroadcastReceiver() {
            override fun onReceive(receiverContext: Context?, intent: Intent?) {
                trySend(read())
            }
        }
        ContextCompat.registerReceiver(
            context,
            powerReceiver,
            IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )

        val animationObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(read())
            }
        }
        resolver.registerContentObserver(
            Settings.Global.getUriFor(Settings.Global.ANIMATOR_DURATION_SCALE),
            false,
            animationObserver,
        )

        awaitClose {
            context.unregisterReceiver(powerReceiver)
            resolver.unregisterContentObserver(animationObserver)
        }
    }
        .distinctUntilChanged()
        .conflate()
}
