package com.onlyus.app.features.onboarding

import androidx.activity.compose.BackHandler
import androidx.annotation.StringRes
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.components.ChatIllustration
import com.onlyus.app.core.designsystem.components.GlassButton
import com.onlyus.app.core.designsystem.components.GlassButtonStyle
import com.onlyus.app.core.designsystem.components.OnlyUsEmblem
import com.onlyus.app.core.designsystem.components.PhotosIllustration
import com.onlyus.app.core.designsystem.theme.OnlyUsMotion
import com.onlyus.app.core.designsystem.theme.OnlyUsShapes
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme
import kotlinx.coroutines.launch

private enum class PageVisual { Emblem, Chat, Photos }

private data class OnboardingPage(
    @StringRes val title: Int,
    @StringRes val body: Int,
    val visual: PageVisual,
)

private val Pages = listOf(
    OnboardingPage(R.string.onboarding_page1_title, R.string.onboarding_page1_body, PageVisual.Emblem),
    OnboardingPage(R.string.onboarding_page2_title, R.string.onboarding_page2_body, PageVisual.Chat),
    OnboardingPage(R.string.onboarding_page3_title, R.string.onboarding_page3_body, PageVisual.Photos),
)

/** Every page gives its picture the same height, so the headline sits in the same place as you swipe. */
private val VisualHeight = 190.dp

/**
 * Three calm pages about what the app is for. Swipe, tap Continue, or Skip. Back steps to the previous page.
 * Finishing (or skipping) is remembered, so this is shown once.
 */
@Composable
fun OnboardingScreen(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: OnboardingViewModel = hiltViewModel(),
) {
    val spacing = OnlyUsTheme.spacing
    val reducedMotion = OnlyUsTheme.effects.reducedMotion
    val pagerState = rememberPagerState(pageCount = { Pages.size })
    val scope = rememberCoroutineScope()
    val currentPage = pagerState.currentPage
    val isLastPage = currentPage == Pages.lastIndex
    val finish = { viewModel.complete(onFinished) }

    BackHandler(enabled = currentPage > 0) {
        scope.launch {
            if (reducedMotion) pagerState.scrollToPage(currentPage - 1) else pagerState.animateScrollToPage(currentPage - 1)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // The Skip button keeps its space on the last page, so nothing below it jumps.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .height(56.dp)
                .padding(horizontal = spacing.sm),
            contentAlignment = Alignment.CenterEnd,
        ) {
            if (!isLastPage) {
                GlassButton(
                    text = stringResource(R.string.onboarding_skip),
                    onClick = finish,
                    style = GlassButtonStyle.Text,
                )
            }
        }

        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f),
        ) { index ->
            OnboardingPageContent(page = Pages[index])
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = spacing.xl)
                .padding(bottom = spacing.xl),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(spacing.xl),
        ) {
            PageIndicator(pageCount = Pages.size, currentPage = currentPage)

            Crossfade(
                targetState = isLastPage,
                animationSpec = if (reducedMotion) snap() else tween(OnlyUsMotion.Short),
                label = "onboardingAction",
            ) { last ->
                GlassButton(
                    text = stringResource(if (last) R.string.onboarding_get_started else R.string.onboarding_continue),
                    onClick = {
                        if (last) {
                            finish()
                        } else {
                            scope.launch {
                                val next = currentPage + 1
                                if (reducedMotion) pagerState.scrollToPage(next) else pagerState.animateScrollToPage(next)
                            }
                        }
                    },
                    modifier = Modifier
                        .widthIn(max = 420.dp)
                        .fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun OnboardingPageContent(
    page: OnboardingPage,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val spacing = OnlyUsTheme.spacing

    // The content is centred when there is room and scrolls when there is not (small phones, large font sizes).
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val viewportHeight = maxHeight
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .heightIn(min = viewportHeight)
                .padding(horizontal = spacing.xl, vertical = spacing.lg),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                modifier = Modifier.height(VisualHeight),
                contentAlignment = Alignment.Center,
            ) {
                when (page.visual) {
                    PageVisual.Emblem -> OnlyUsEmblem(size = 184.dp)
                    PageVisual.Chat -> ChatIllustration(width = 240.dp)
                    PageVisual.Photos -> PhotosIllustration(width = 240.dp)
                }
            }

            Spacer(Modifier.height(spacing.xl))

            Text(
                text = stringResource(page.title),
                style = MaterialTheme.typography.headlineLarge,
                color = scheme.onBackground,
                textAlign = TextAlign.Center,
                modifier = Modifier.semantics { heading() },
            )

            Spacer(Modifier.height(spacing.md))

            Text(
                text = stringResource(page.body),
                style = MaterialTheme.typography.bodyLarge,
                color = scheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.widthIn(max = 340.dp),
            )
        }
    }
}

/** Dots that stretch into a pill for the current page. Announced as "Page 2 of 3" rather than as three loose dots. */
@Composable
private fun PageIndicator(
    pageCount: Int,
    currentPage: Int,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val reducedMotion = OnlyUsTheme.effects.reducedMotion
    val description = stringResource(R.string.onboarding_page_indicator, currentPage + 1, pageCount)

    Row(
        modifier = modifier.clearAndSetSemantics { contentDescription = description },
        horizontalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(pageCount) { index ->
            val selected = index == currentPage
            val width by animateDpAsState(
                targetValue = if (selected) 28.dp else 8.dp,
                animationSpec = if (reducedMotion) snap() else tween(OnlyUsMotion.Short),
                label = "dotWidth",
            )
            val color by animateColorAsState(
                targetValue = if (selected) scheme.primary else scheme.outline,
                label = "dotColor",
            )
            Box(
                modifier = Modifier
                    .width(width)
                    .height(8.dp)
                    .clip(OnlyUsShapes.Pill)
                    .background(color),
            )
        }
    }
}
