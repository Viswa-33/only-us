package com.onlyus.app.core.designsystem.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.onlyus.app.core.designsystem.theme.OnlyUsMotion
import com.onlyus.app.core.designsystem.theme.OnlyUsRadius
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

@Immutable
data class NavBarItem(
    val label: String,
    @DrawableRes val icon: Int,
    val badgeCount: Int = 0,
)

/**
 * The floating glass navigation bar. A soft pill slides to the selected item with a gentle spring, and every item shows
 * its label, so nothing depends on guessing an icon. Screen readers announce each item as a tab, with a badge if any.
 *
 * Dock it below the screen content, not on top of it: the glass is translucent, so it looks best over the plain
 * background gradient rather than over scrolling text. It already handles the system navigation bar inset.
 */
@Composable
fun GlassNavigationBar(
    items: List<NavBarItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val glass = OnlyUsTheme.glass
    val effects = OnlyUsTheme.effects
    val spacing = OnlyUsTheme.spacing
    val barShape = RoundedCornerShape(OnlyUsRadius.xl)
    val itemShape = RoundedCornerShape(OnlyUsRadius.lg)
    val inner = 6.dp

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = spacing.lg, vertical = spacing.md),
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .glassSurface(shape = barShape, glass = glass, effects = effects, strength = GlassStrength.Strong)
                .clip(barShape)
                .padding(inner)
                .selectableGroup(),
        ) {
            val itemWidth = (maxWidth - inner * 2) / items.size
            val indicatorX = animateDpAsState(
                targetValue = itemWidth * selectedIndex,
                animationSpec = if (effects.reducedMotion) {
                    snap()
                } else {
                    spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)
                },
                label = "navIndicator",
            )

            Box(modifier = Modifier.fillMaxWidth()) {
                // The sliding selection pill, behind the items. Its position is read in the layout phase only.
                Box(modifier = Modifier.matchParentSize()) {
                    Box(
                        modifier = Modifier
                            .offset { IntOffset(indicatorX.value.roundToPx(), 0) }
                            .width(itemWidth)
                            .fillMaxHeight()
                            .background(glass.selectionFill, itemShape)
                            .border(1.dp, glass.selectionBorder, itemShape),
                    )
                }
                Row(modifier = Modifier.fillMaxWidth()) {
                    items.forEachIndexed { index, item ->
                        NavBarButton(
                            item = item,
                            selected = index == selectedIndex,
                            onClick = { onSelect(index) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NavBarButton(
    item: NavBarItem,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val tint by animateColorAsState(
        targetValue = if (selected) scheme.primary else scheme.onSurfaceVariant,
        label = "navTint",
    )
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .heightIn(min = 64.dp)
            .clip(RoundedCornerShape(OnlyUsRadius.lg))
            .selectable(
                selected = selected,
                interactionSource = interactionSource,
                indication = ripple(color = scheme.primary),
                role = Role.Tab,
                onClick = onClick,
            )
            .padding(vertical = OnlyUsTheme.spacing.sm),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.xxs),
        ) {
            Box {
                Icon(
                    painter = painterResource(item.icon),
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                    tint = tint,
                )
                NotificationBadge(
                    count = item.badgeCount,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 9.dp, y = (-7).dp),
                )
            }
            Text(
                text = item.label,
                style = MaterialTheme.typography.labelSmall,
                color = tint,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/**
 * A transparent top bar with a Playfair Display title. Pass [scrolled] = true once content has scrolled beneath it and
 * it fades in a calm surface and a hairline, so the title never sits on top of scrolling text. It handles the status
 * bar inset itself.
 */
@Composable
fun OnlyUsTopBar(
    title: String,
    modifier: Modifier = Modifier,
    scrolled: Boolean = false,
    navigationIcon: (@Composable () -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val scheme = MaterialTheme.colorScheme
    val spacing = OnlyUsTheme.spacing
    val reducedMotion = OnlyUsTheme.effects.reducedMotion
    val surfaceAlpha = animateFloatAsState(
        targetValue = if (scrolled) 1f else 0f,
        animationSpec = if (reducedMotion) snap() else tween(OnlyUsMotion.Short),
        label = "topBarSurface",
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .drawBehind { drawRect(color = scheme.surface.copy(alpha = 0.94f * surfaceAlpha.value)) },
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .heightIn(min = 64.dp)
                .padding(horizontal = spacing.sm),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (navigationIcon != null) navigationIcon()
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = scheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = spacing.md)
                    .semantics { heading() },
            )
            actions()
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .graphicsLayer { alpha = surfaceAlpha.value }
                .background(scheme.outlineVariant),
        )
    }
}
