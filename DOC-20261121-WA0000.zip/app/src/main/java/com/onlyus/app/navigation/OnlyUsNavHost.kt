package com.onlyus.app.navigation

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.onlyus.app.core.designsystem.theme.OnlyUsMotion
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme
import com.onlyus.app.features.onboarding.OnboardingScreen
import com.onlyus.app.features.showcase.ShowcaseScreen
import com.onlyus.app.features.splash.SplashScreen

/** A new screen rises about 1/28 of its height while fading in: enough to feel soft, too little to feel busy. */
private const val RiseDivisor = 28

@Composable
fun OnlyUsNavHost(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    val reducedMotion = OnlyUsTheme.effects.reducedMotion

    val enter: EnterTransition = remember(reducedMotion) {
        if (reducedMotion) {
            EnterTransition.None
        } else {
            fadeIn(tween(OnlyUsMotion.Medium)) +
                slideInVertically(tween(OnlyUsMotion.Medium)) { fullHeight -> fullHeight / RiseDivisor }
        }
    }
    val exit: ExitTransition = remember(reducedMotion) {
        if (reducedMotion) ExitTransition.None else fadeOut(tween(OnlyUsMotion.Short))
    }

    NavHost(
        navController = navController,
        startDestination = Destinations.Splash,
        modifier = modifier,
        enterTransition = { enter },
        exitTransition = { exit },
        popEnterTransition = { enter },
        popExitTransition = { exit },
    ) {
        composable(Destinations.Splash) {
            SplashScreen(
                onFinished = { destination ->
                    navController.navigate(destination) {
                        // The splash is never part of the back stack: Back from the first screen leaves the app.
                        popUpTo(Destinations.Splash) { inclusive = true }
                        launchSingleTop = true
                    }
                },
            )
        }
        composable(Destinations.Onboarding) {
            OnboardingScreen(
                onFinished = {
                    navController.navigate(Destinations.Showcase) {
                        popUpTo(Destinations.Onboarding) { inclusive = true }
                        launchSingleTop = true
                    }
                },
            )
        }
        composable(Destinations.Showcase) {
            ShowcaseScreen()
        }
    }
}
