package com.onlyus.app.ui

import androidx.activity.compose.LocalActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.onlyus.app.core.designsystem.components.OnlyUsBackground
import com.onlyus.app.core.designsystem.theme.OnlyUsEffects
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme
import com.onlyus.app.core.preferences.ThemeMode
import com.onlyus.app.navigation.OnlyUsNavHost

/**
 * The root of the UI: theme, the shared background gradient, and navigation.
 *
 * The background sits behind the NavHost, so screens are transparent and the gradient never redraws or flickers
 * while screens change.
 */
@Composable
fun OnlyUsApp(
    themeMode: ThemeMode,
    effects: OnlyUsEffects,
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    OnlyUsTheme(darkTheme = darkTheme, effects = effects) {
        SystemBarsEffect(darkTheme = darkTheme)
        OnlyUsBackground(modifier = Modifier.fillMaxSize()) {
            OnlyUsNavHost(modifier = Modifier.fillMaxSize())
        }
    }
}

/**
 * Keeps the status and navigation bar icons readable: dark icons over the light theme, light icons over the dark theme.
 * This follows the app's own theme choice, which may differ from the system setting.
 */
@Composable
private fun SystemBarsEffect(darkTheme: Boolean) {
    val activity = LocalActivity.current
    SideEffect {
        val window = activity?.window ?: return@SideEffect
        // No grey scrim behind the three-button navigation bar: our gradient already sits underneath it.
        window.isNavigationBarContrastEnforced = false
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = !darkTheme
        controller.isAppearanceLightNavigationBars = !darkTheme
    }
}
