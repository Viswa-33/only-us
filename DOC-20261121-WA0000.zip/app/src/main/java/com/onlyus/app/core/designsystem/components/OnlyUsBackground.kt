package com.onlyus.app.core.designsystem.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

/**
 * The shared screen background: a soft ivory-to-blush gradient (charcoal to plum in dark mode) with two faint, static glows.
 * The glows are plain radial gradients and are skipped entirely when effects are reduced.
 * Brushes are built once per size, and nothing here animates.
 */
@Composable
fun OnlyUsBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val brand = OnlyUsTheme.brand
    val reduced = OnlyUsTheme.effects.reducedEffects

    Box(
        modifier = modifier.drawWithCache {
            val glowRadius = size.maxDimension * 0.55f
            val topGlow = Brush.radialGradient(
                colors = listOf(brand.orbPrimary, Color.Transparent),
                center = Offset(size.width * 0.12f, size.height * 0.04f),
                radius = glowRadius,
            )
            val bottomGlow = Brush.radialGradient(
                colors = listOf(brand.orbSecondary, Color.Transparent),
                center = Offset(size.width * 0.95f, size.height * 0.92f),
                radius = glowRadius * 0.9f,
            )
            onDrawBehind {
                drawRect(brush = brand.backgroundBrush)
                if (!reduced) {
                    drawRect(brush = topGlow)
                    drawRect(brush = bottomGlow)
                }
            }
        },
        content = content,
    )
}
