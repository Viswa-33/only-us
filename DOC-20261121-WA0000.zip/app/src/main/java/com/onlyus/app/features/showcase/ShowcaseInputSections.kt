package com.onlyus.app.features.showcase

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.components.ChatIllustration
import com.onlyus.app.core.designsystem.components.EmptyState
import com.onlyus.app.core.designsystem.components.FieldStatus
import com.onlyus.app.core.designsystem.components.GlassButton
import com.onlyus.app.core.designsystem.components.GlassButtonStyle
import com.onlyus.app.core.designsystem.components.GlassCard
import com.onlyus.app.core.designsystem.components.LetterIllustration
import com.onlyus.app.core.designsystem.components.NotificationBadge
import com.onlyus.app.core.designsystem.components.OnlyUsDivider
import com.onlyus.app.core.designsystem.components.OnlyUsLoadingIndicator
import com.onlyus.app.core.designsystem.components.OnlyUsTextField
import com.onlyus.app.core.designsystem.components.OrnamentDivider
import com.onlyus.app.core.designsystem.components.PhotosIllustration
import com.onlyus.app.core.designsystem.components.SectionHeader
import com.onlyus.app.core.designsystem.theme.OnlyUsMotion
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme
import kotlinx.coroutines.delay

/*
 * The components half of the gallery, part two: input fields, loading and badges, dividers and headers, empty states.
 */

private const val MinNameLength = 2
private const val LoaderDemoMillis = 2500L
private const val EmptyExampleCount = 3

@Composable
internal fun FieldsSection() {
    val focusManager = LocalFocusManager.current
    val sampleNickname = stringResource(R.string.sample_first_name_one)
    val sampleInvalidEmail = stringResource(R.string.sample_email_invalid)

    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf(sampleInvalidEmail) }
    var nickname by rememberSaveable { mutableStateOf(sampleNickname) }
    var password by rememberSaveable { mutableStateOf("") }

    // The first field validates as you type: quiet while empty, an error under two characters, success from two.
    val nameStatus = when {
        name.isEmpty() -> FieldStatus.Default
        name.trim().length < MinNameLength -> FieldStatus.Error
        else -> FieldStatus.Success
    }
    val nameSupport = stringResource(
        when (nameStatus) {
            FieldStatus.Default -> R.string.field_name_hint
            FieldStatus.Error -> R.string.field_name_error
            FieldStatus.Success -> R.string.field_name_success
        },
    )

    ShowcaseSection(
        title = stringResource(R.string.showcase_fields_title),
        overline = stringResource(R.string.showcase_overline_components),
        hint = stringResource(R.string.showcase_fields_hint),
    ) {
        OnlyUsTextField(
            value = name,
            onValueChange = { name = it },
            label = stringResource(R.string.field_name_label),
            modifier = Modifier.fillMaxWidth(),
            status = nameStatus,
            supportingText = nameSupport,
            leadingIcon = R.drawable.ic_nav_profile,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        )
        OnlyUsTextField(
            value = email,
            onValueChange = { email = it },
            label = stringResource(R.string.field_email_label),
            modifier = Modifier.fillMaxWidth(),
            status = FieldStatus.Error,
            supportingText = stringResource(R.string.field_email_error),
            leadingIcon = R.drawable.ic_mail,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
        )
        OnlyUsTextField(
            value = nickname,
            onValueChange = { nickname = it },
            label = stringResource(R.string.field_nickname_label),
            modifier = Modifier.fillMaxWidth(),
            status = FieldStatus.Success,
            supportingText = stringResource(R.string.field_name_success),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        )
        OnlyUsTextField(
            value = password,
            onValueChange = { password = it },
            label = stringResource(R.string.field_password_label),
            modifier = Modifier.fillMaxWidth(),
            supportingText = stringResource(R.string.field_password_hint),
            isPassword = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
        )
        OnlyUsTextField(
            value = stringResource(R.string.field_disabled_value),
            onValueChange = {},
            label = stringResource(R.string.field_disabled_label),
            modifier = Modifier.fillMaxWidth(),
            enabled = false,
            supportingText = stringResource(R.string.field_disabled_hint),
        )
    }
}

@Composable
internal fun FeedbackSection() {
    val spacing = OnlyUsTheme.spacing
    var running by remember { mutableStateOf(false) }

    // A finite demo: the heart beats for a moment, then settles, like real loading would.
    LaunchedEffect(running) {
        if (running) {
            delay(LoaderDemoMillis)
            running = false
        }
    }

    ShowcaseSection(
        title = stringResource(R.string.showcase_feedback_title),
        overline = stringResource(R.string.showcase_overline_components),
        hint = stringResource(R.string.showcase_feedback_hint),
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(spacing.xl),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OnlyUsLoadingIndicator(size = 56.dp, animating = running)
            GlassButton(
                text = stringResource(if (running) R.string.loading else R.string.button_show_loader),
                onClick = { running = true },
                style = GlassButtonStyle.Secondary,
                enabled = !running,
            )
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(spacing.lg),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NotificationBadge(count = 1)
            NotificationBadge(count = 12)
            NotificationBadge(count = 128)
            Text(
                text = stringResource(R.string.feedback_badges_caption),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
internal fun DividersSection() {
    ShowcaseSection(
        title = stringResource(R.string.showcase_dividers_title),
        overline = stringResource(R.string.showcase_overline_components),
        hint = stringResource(R.string.showcase_dividers_hint),
    ) {
        OnlyUsDivider()
        OrnamentDivider()
        SectionHeader(
            title = stringResource(R.string.sample_header_title),
            overline = stringResource(R.string.sample_header_overline),
            subtitle = stringResource(R.string.sample_header_subtitle),
            action = {
                GlassButton(
                    text = stringResource(R.string.action_see_all),
                    onClick = {},
                    style = GlassButtonStyle.Text,
                )
            },
        )
    }
}

@Composable
internal fun EmptyStateSection() {
    val spacing = OnlyUsTheme.spacing
    val reducedMotion = OnlyUsTheme.effects.reducedMotion
    var example by rememberSaveable { mutableIntStateOf(0) }
    val nextLabel = stringResource(R.string.empty_next_example)

    ShowcaseSection(
        title = stringResource(R.string.showcase_empty_title),
        overline = stringResource(R.string.showcase_overline_components),
        hint = stringResource(R.string.showcase_empty_hint),
    ) {
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = spacing.lg, vertical = spacing.xl),
        ) {
            Crossfade(
                targetState = example,
                animationSpec = if (reducedMotion) snap() else tween(OnlyUsMotion.Medium),
                label = "emptyExample",
            ) { index ->
                val showNext = { example = (index + 1) % EmptyExampleCount }
                when (index) {
                    0 -> EmptyState(
                        illustration = { LetterIllustration() },
                        title = stringResource(R.string.empty_letters_title),
                        body = stringResource(R.string.empty_letters_body),
                        actionLabel = nextLabel,
                        onAction = showNext,
                    )
                    1 -> EmptyState(
                        illustration = { ChatIllustration() },
                        title = stringResource(R.string.empty_chat_title),
                        body = stringResource(R.string.empty_chat_body),
                        actionLabel = nextLabel,
                        onAction = showNext,
                    )
                    else -> EmptyState(
                        illustration = { PhotosIllustration() },
                        title = stringResource(R.string.empty_photos_title),
                        body = stringResource(R.string.empty_photos_body),
                        actionLabel = nextLabel,
                        onAction = showNext,
                    )
                }
            }
        }
    }
}
