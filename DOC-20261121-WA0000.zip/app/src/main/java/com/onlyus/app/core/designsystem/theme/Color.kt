package com.onlyus.app.core.designsystem.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/**
 * The single place where raw colours are defined. Screens and components never write hex values:
 * they read roles from MaterialTheme.colorScheme, OnlyUsTheme.glass or OnlyUsTheme.brand.
 *
 * Palette: deep burgundy, blush pink, warm ivory, rose gold and elegant charcoal.
 * Light mode is warm ivory with blush; dark mode is deep charcoal and plum with muted rose accents.
 * Contrast (WCAG 2.x) is audited for every text/background pair: body text at least 7:1,
 * secondary text and controls at least 4.5:1, outlines at least 3:1.
 */
internal object OnlyUsPalette {
    // Deep burgundy
    val Burgundy950 = Color(0xFF3B0A1C)
    val Burgundy800 = Color(0xFF5F1632)
    val Burgundy700 = Color(0xFF7B1E3A) // primary on light
    val Burgundy600 = Color(0xFF8E2646)
    val BurgundyContainerDark = Color(0xFF6A1F39)

    // Blush pink and muted rose
    val Blush100 = Color(0xFFF8DADF)
    val Blush200 = Color(0xFFF2B8C6)
    val MutedRose = Color(0xFFE3A5B3) // primary on dark
    val Rose500 = Color(0xFFA33A57) // tertiary on light

    // Warm ivory
    val Ivory50 = Color(0xFFFFFBF7) // surface
    val Ivory100 = Color(0xFFFBF5EE) // background, must equal res/values/colors.xml window_background
    val Ivory200 = Color(0xFFF9ECE8)
    val BlushWash = Color(0xFFF6DFDF)

    // Rose gold
    val RoseGold300 = Color(0xFFE9B8AC) // light metallic, decorative
    val RoseGold500 = Color(0xFFB76E79) // classic rose gold, decorative and graphics
    val RoseGold700 = Color(0xFF8E4B57) // rose gold for text and icons on light surfaces
    val Champagne = Color(0xFFE4B9AB) // rose gold on dark surfaces

    // Elegant charcoal and plum
    val Ink = Color(0xFF2A2327) // text on light
    val InkVariant = Color(0xFF5E5358)
    val Charcoal900 = Color(0xFF161214) // background on dark, must equal res/values-night/colors.xml window_background
    val Plum900 = Color(0xFF21171F)
    val PlumDeep = Color(0xFF1A1318)
    val OnDark = Color(0xFFF4EAEA)
    val OnDarkVariant = Color(0xFFCDBEC3)
}

internal val LightColorScheme: ColorScheme = lightColorScheme(
    primary = OnlyUsPalette.Burgundy700,
    onPrimary = Color.White,
    primaryContainer = OnlyUsPalette.Blush100,
    onPrimaryContainer = OnlyUsPalette.Burgundy950,
    inversePrimary = OnlyUsPalette.MutedRose,
    secondary = OnlyUsPalette.RoseGold700,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF4E0DA),
    onSecondaryContainer = Color(0xFF3A1D22),
    tertiary = OnlyUsPalette.Rose500,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFBD9E0),
    onTertiaryContainer = Color(0xFF40001A),
    background = OnlyUsPalette.Ivory100,
    onBackground = OnlyUsPalette.Ink,
    surface = OnlyUsPalette.Ivory50,
    onSurface = OnlyUsPalette.Ink,
    surfaceVariant = Color(0xFFF2E6E2),
    onSurfaceVariant = OnlyUsPalette.InkVariant,
    surfaceTint = OnlyUsPalette.Burgundy700,
    inverseSurface = Color(0xFF3A3034),
    inverseOnSurface = Color(0xFFFBEFEF),
    error = Color(0xFFB3261E),
    onError = Color.White,
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = Color(0xFF410E0B),
    outline = Color(0xFF84737A),
    outlineVariant = Color(0xFFE6D6D3),
    scrim = Color.Black,
    surfaceBright = OnlyUsPalette.Ivory50,
    surfaceDim = Color(0xFFE8DCD7),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFFEF8F3),
    surfaceContainer = Color(0xFFF8EFE9),
    surfaceContainerHigh = Color(0xFFF3E8E3),
    surfaceContainerHighest = Color(0xFFEDE1DD),
)

internal val DarkColorScheme: ColorScheme = darkColorScheme(
    primary = OnlyUsPalette.MutedRose,
    onPrimary = Color(0xFF45101F),
    primaryContainer = OnlyUsPalette.BurgundyContainerDark,
    onPrimaryContainer = Color(0xFFFFD9E1),
    inversePrimary = OnlyUsPalette.Burgundy700,
    secondary = OnlyUsPalette.Champagne,
    onSecondary = Color(0xFF44221A),
    secondaryContainer = Color(0xFF5B3B34),
    onSecondaryContainer = Color(0xFFFFDCD2),
    tertiary = OnlyUsPalette.Blush200,
    onTertiary = Color(0xFF4B1A2B),
    tertiaryContainer = Color(0xFF6E2D42),
    onTertiaryContainer = Color(0xFFFFD9E3),
    background = OnlyUsPalette.Charcoal900,
    onBackground = OnlyUsPalette.OnDark,
    surface = Color(0xFF1E181B),
    onSurface = OnlyUsPalette.OnDark,
    surfaceVariant = Color(0xFF4A3E44),
    onSurfaceVariant = OnlyUsPalette.OnDarkVariant,
    surfaceTint = OnlyUsPalette.MutedRose,
    inverseSurface = OnlyUsPalette.OnDark,
    inverseOnSurface = Color(0xFF332A2E),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410),
    errorContainer = Color(0xFF8C1D18),
    onErrorContainer = Color(0xFFF9DEDC),
    outline = Color(0xFFA7959C),
    outlineVariant = Color(0xFF4D4147),
    scrim = Color.Black,
    surfaceBright = Color(0xFF3B3036),
    surfaceDim = Color(0xFF141011),
    surfaceContainerLowest = Color(0xFF110D0F),
    surfaceContainerLow = Color(0xFF1A1417),
    surfaceContainer = Color(0xFF221A1E),
    surfaceContainerHigh = Color(0xFF2C2227),
    surfaceContainerHighest = Color(0xFF372C32),
)
