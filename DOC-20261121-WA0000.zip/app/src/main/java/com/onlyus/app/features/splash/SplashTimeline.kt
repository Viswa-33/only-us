package com.onlyus.app.features.splash

import kotlin.math.PI
import kotlin.math.sin

/*
 * The splash choreography as plain numbers. Everything on screen is a function of ONE overall progress value from 0
 * to 1, so the whole splash is a single finite animation, never an infinite one. This file has no Android or Compose
 * imports, which keeps it trivially unit-testable.
 */

/** A slice of the overall progress, from [start] to [end], both between 0 and 1. */
internal data class Window(val start: Float, val end: Float)

internal object SplashTimeline {
    /** The full story: emblem, hearts drifting together, wordmark, ornament, tagline. */
    const val FullDurationMillis = 2800

    /** Same story, shorter, when effects are reduced (Battery Saver, low-memory device, or the user's choice). */
    const val ReducedDurationMillis = 1100

    /** With system animations switched off nothing moves: the finished splash simply stays up this long. */
    const val StaticHoldMillis = 700L

    val Emblem = Window(0.00f, 0.30f)
    val Hearts = Window(0.08f, 0.46f)
    val Wordmark = Window(0.30f, 0.55f)
    val Ornament = Window(0.50f, 0.68f)
    val TaglineFirst = Window(0.60f, 0.78f)
    val TaglineSecond = Window(0.70f, 0.88f)
}

private val Pi = PI.toFloat()
private val TwoPi = (2.0 * PI).toFloat()

/** How far through [window] the overall [progress] is, from 0 to 1, held at 0 before it and at 1 after it. */
internal fun segment(progress: Float, window: Window): Float {
    val span = window.end - window.start
    if (span <= 0f) return if (progress >= window.end) 1f else 0f
    return ((progress - window.start) / span).coerceIn(0f, 1f)
}

/** Fast at the start, gentle at the end: things arrive and settle. */
internal fun easeOutCubic(t: Float): Float {
    val remaining = 1f - t.coerceIn(0f, 1f)
    return 1f - remaining * remaining * remaining
}

/**
 * One small heart that rises behind the logo. [x] is where it starts across the width (0..1), [rise] is how far up it
 * travels as a fraction of the height, [sway] is its sideways drift as a fraction of the width, and [tilt] is how many
 * degrees it turns on the way. It is visible only during its own [window].
 */
internal data class FloatingHeart(
    val x: Float,
    val sizeDp: Float,
    val window: Window,
    val rise: Float,
    val sway: Float,
    val tilt: Float,
    val colorIndex: Int,
    val peakAlpha: Float,
)

/** Where a [FloatingHeart] is at one moment: position as fractions of the screen, opacity and rotation. */
internal data class HeartFrame(val x: Float, val y: Float, val alpha: Float, val rotation: Float)

private const val HeartStartY = 0.96f

internal fun FloatingHeart.frameAt(progress: Float): HeartFrame {
    val t = segment(progress, window)
    return HeartFrame(
        x = x + sway * sin(t * TwoPi),
        y = HeartStartY - rise * easeOutCubic(t),
        // Fades in and out smoothly: zero at both ends of its window, strongest in the middle.
        alpha = (peakAlpha * sin(t * Pi)).coerceAtLeast(0f),
        rotation = tilt * t,
    )
}

/** Seven hearts, fixed rather than random, so the splash looks the same every time and the tests are exact. */
internal val SplashHearts: List<FloatingHeart> = listOf(
    FloatingHeart(x = 0.14f, sizeDp = 14f, window = Window(0.10f, 0.78f), rise = 0.46f, sway = 0.035f, tilt = -14f, colorIndex = 0, peakAlpha = 0.55f),
    FloatingHeart(x = 0.82f, sizeDp = 20f, window = Window(0.16f, 0.90f), rise = 0.52f, sway = -0.045f, tilt = 12f, colorIndex = 1, peakAlpha = 0.45f),
    FloatingHeart(x = 0.30f, sizeDp = 10f, window = Window(0.24f, 0.84f), rise = 0.38f, sway = 0.030f, tilt = 8f, colorIndex = 2, peakAlpha = 0.60f),
    FloatingHeart(x = 0.66f, sizeDp = 12f, window = Window(0.30f, 0.96f), rise = 0.42f, sway = -0.030f, tilt = -10f, colorIndex = 3, peakAlpha = 0.50f),
    FloatingHeart(x = 0.92f, sizeDp = 9f, window = Window(0.42f, 1.00f), rise = 0.30f, sway = 0.020f, tilt = 16f, colorIndex = 0, peakAlpha = 0.50f),
    FloatingHeart(x = 0.06f, sizeDp = 11f, window = Window(0.46f, 1.00f), rise = 0.34f, sway = 0.030f, tilt = -18f, colorIndex = 1, peakAlpha = 0.45f),
    FloatingHeart(x = 0.50f, sizeDp = 8f, window = Window(0.36f, 0.92f), rise = 0.28f, sway = -0.020f, tilt = 6f, colorIndex = 2, peakAlpha = 0.40f),
)
