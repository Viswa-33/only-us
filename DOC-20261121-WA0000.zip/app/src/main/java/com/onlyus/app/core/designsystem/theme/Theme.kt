package com.onlyus.app.core.designsystem.theme

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf

private val DefaultSpacing = Spacing()

// Spacing and effects only change on a user action, so they are static. Glass and brand colours are blended every
// frame while the theme switches, so they are not static: only the composables that read them recompose.
val LocalSpacing = staticCompositionLocalOf { DefaultSpacing }
val LocalOnlyUsEffects = staticCompositionLocalOf { OnlyUsEffects.Full }
val LocalGlassColors = compositionLocalOf<GlassColors> { LightGlassColors }
val LocalBrandColors = compositionLocalOf<BrandColors> { LightBrandColors }

/** Access to the design tokens that are not part of MaterialTheme. */
object OnlyUsTheme {
    val spacing: Spacing
        @Composable @ReadOnlyComposable get() = LocalSpacing.current

    val glass: GlassColors
        @Composable @ReadOnlyComposable get() = LocalGlassColors.current

    val brand: BrandColors
        @Composable @ReadOnlyComposable get() = LocalBrandColors.current

    val effects: OnlyUsEffects
        @Composable @ReadOnlyComposable get() = LocalOnlyUsEffects.current
}

/**
 * Root theme: Material 3 colours, type and shapes plus the Only Us glass, brand, spacing and effects tokens.
 *
 * Switching between light and dark blends every colour over a short animation. When effects or motion are reduced,
 * the switch is instant. Dynamic (wallpaper) colour is deliberately not used, so the palette is the same on every phone.
 */
@Composable
fun OnlyUsTheme(
    darkTheme: Boolean,
    effects: OnlyUsEffects = OnlyUsEffects.Full,
    content: @Composable () -> Unit,
) {
    val animate = !effects.reducedEffects && !effects.reducedMotion
    val spec: AnimationSpec<Float> =
        if (animate) tween<Float>(durationMillis = OnlyUsMotion.Long, easing = FastOutSlowInEasing) else snap<Float>()
    val progress by animateFloatAsState(
        targetValue = if (darkTheme) 1f else 0f,
        animationSpec = spec,
        label = "OnlyUsThemeProgress",
    )

    val colorScheme = remember(progress) { themedColorScheme(progress) }
    val glass = remember(progress) { themedGlassColors(progress) }
    val brand = remember(progress) { themedBrandColors(progress) }

    CompositionLocalProvider(
        LocalSpacing provides DefaultSpacing,
        LocalGlassColors provides glass,
        LocalBrandColors provides brand,
        LocalOnlyUsEffects provides effects,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = OnlyUsTypography,
            shapes = OnlyUsMaterialShapes,
        ) {
            // Plain Text and Icon outside a Surface would otherwise default to black.
            CompositionLocalProvider(LocalContentColor provides colorScheme.onBackground) {
                ProvideTextStyle(value = OnlyUsTypography.bodyLarge, content = content)
            }
        }
    }
}
