package com.onlyus.app.core.designsystem.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * The "glass recipe". Glass is simulated, never blurred: a translucent gradient fill, a faint top sheen,
 * a thin rose-gold border and a soft shadow. All brushes are built once per theme, not per frame.
 * When effects are reduced, components use [flatFill] and [flatBorder] instead.
 */
@Immutable
class GlassColors(
    val fillTop: Color,
    val fillBottom: Color,
    val strongFillTop: Color,
    val strongFillBottom: Color,
    val borderStart: Color,
    val borderEnd: Color,
    val sheen: Color,
    val shadow: Color,
    val selectionFill: Color,
    val selectionBorder: Color,
    val flatFill: Color,
    val flatBorder: Color,
) {
    val fill: Brush = Brush.verticalGradient(listOf(fillTop, fillBottom))
    val strongFill: Brush = Brush.verticalGradient(listOf(strongFillTop, strongFillBottom))
    val border: Brush = Brush.linearGradient(listOf(borderStart, borderEnd))
    val sheenBrush: Brush = Brush.verticalGradient(
        0f to sheen,
        0.45f to Color.Transparent,
        1f to Color.Transparent,
    )
}

/** Brand colours that have no Material 3 role: gradients, action buttons, hearts, logo, status. */
@Immutable
class BrandColors(
    val backgroundTop: Color,
    val backgroundMid: Color,
    val backgroundBottom: Color,
    val splashTop: Color,
    val splashMid: Color,
    val splashBottom: Color,
    val orbPrimary: Color,
    val orbSecondary: Color,
    val actionStart: Color,
    val actionEnd: Color,
    val onAction: Color,
    val actionBorder: Color,
    val roseGold: Color,
    val roseGoldLight: Color,
    val heartRoseGoldStart: Color,
    val heartRoseGoldEnd: Color,
    val heartBurgundyStart: Color,
    val heartBurgundyEnd: Color,
    val wordmarkStart: Color,
    val wordmarkEnd: Color,
    val halo: Color,
    val logoDiscTop: Color,
    val logoDiscBottom: Color,
    val success: Color,
    val onSuccess: Color,
    val successContainer: Color,
    val onSuccessContainer: Color,
    val illustrationBackdrop: Color,
    val floatingHearts: List<Color>,
) {
    val backgroundBrush: Brush = Brush.verticalGradient(
        0f to backgroundTop,
        0.55f to backgroundMid,
        1f to backgroundBottom,
    )
    val splashBrush: Brush = Brush.verticalGradient(
        0f to splashTop,
        0.5f to splashMid,
        1f to splashBottom,
    )
    val actionBrush: Brush = Brush.horizontalGradient(listOf(actionStart, actionEnd))
    val actionSheen: Brush = Brush.verticalGradient(
        0f to Color.White.copy(alpha = 0.16f),
        0.45f to Color.Transparent,
        1f to Color.Transparent,
    )

    // Unit-space gradients: drawn inside a transform that maps the unit heart onto its real size.
    val heartRoseGoldBrush: Brush = Brush.linearGradient(
        listOf(heartRoseGoldStart, heartRoseGoldEnd),
        start = Offset.Zero,
        end = Offset(1f, 1f),
    )
    val heartBurgundyBrush: Brush = Brush.linearGradient(
        listOf(heartBurgundyStart, heartBurgundyEnd),
        start = Offset.Zero,
        end = Offset(1f, 1f),
    )

    // Hairlines that fade out at the ends, for dividers.
    val dividerBrush: Brush = Brush.horizontalGradient(listOf(Color.Transparent, roseGold, Color.Transparent))
    val dividerFadeInBrush: Brush = Brush.horizontalGradient(listOf(Color.Transparent, roseGold))
    val dividerFadeOutBrush: Brush = Brush.horizontalGradient(listOf(roseGold, Color.Transparent))

    // Metallic ring around avatars.
    val ringBrush: Brush = Brush.sweepGradient(listOf(roseGoldLight, roseGold, roseGoldLight, roseGold, roseGoldLight))
}

internal val LightGlassColors = GlassColors(
    fillTop = Color.White.copy(alpha = 0.70f),
    fillBottom = Color.White.copy(alpha = 0.42f),
    strongFillTop = Color.White.copy(alpha = 0.86f),
    strongFillBottom = Color.White.copy(alpha = 0.66f),
    borderStart = Color.White.copy(alpha = 0.95f),
    borderEnd = OnlyUsPalette.RoseGold500.copy(alpha = 0.50f),
    sheen = Color.White.copy(alpha = 0.55f),
    shadow = OnlyUsPalette.Burgundy800.copy(alpha = 0.16f),
    selectionFill = Color.White.copy(alpha = 0.92f),
    selectionBorder = OnlyUsPalette.RoseGold500.copy(alpha = 0.45f),
    flatFill = OnlyUsPalette.Ivory50.copy(alpha = 0.96f),
    flatBorder = Color(0xFFE9D8D3),
)

internal val DarkGlassColors = GlassColors(
    fillTop = Color.White.copy(alpha = 0.09f),
    fillBottom = Color.White.copy(alpha = 0.04f),
    strongFillTop = Color.White.copy(alpha = 0.15f),
    strongFillBottom = Color.White.copy(alpha = 0.08f),
    borderStart = OnlyUsPalette.Champagne.copy(alpha = 0.45f),
    borderEnd = Color.White.copy(alpha = 0.06f),
    sheen = Color.White.copy(alpha = 0.07f),
    shadow = Color.Black.copy(alpha = 0.55f),
    // A burgundy-tinted pill, so the rose-coloured selected label keeps strong contrast on the lighter dark glass.
    selectionFill = OnlyUsPalette.BurgundyContainerDark.copy(alpha = 0.85f),
    selectionBorder = OnlyUsPalette.Champagne.copy(alpha = 0.40f),
    flatFill = Color(0xFF2A2025).copy(alpha = 0.96f),
    flatBorder = Color(0xFF4D4147),
)

internal val LightBrandColors = BrandColors(
    backgroundTop = OnlyUsPalette.Ivory100,
    backgroundMid = OnlyUsPalette.Ivory200,
    backgroundBottom = OnlyUsPalette.BlushWash,
    splashTop = OnlyUsPalette.Ivory100,
    splashMid = Color(0xFFF6D9DC),
    splashBottom = Color(0xFFEDBFC7),
    orbPrimary = OnlyUsPalette.Blush200.copy(alpha = 0.35f),
    orbSecondary = OnlyUsPalette.RoseGold300.copy(alpha = 0.30f),
    actionStart = OnlyUsPalette.Burgundy600,
    actionEnd = OnlyUsPalette.Burgundy800,
    onAction = Color.White,
    actionBorder = OnlyUsPalette.RoseGold300.copy(alpha = 0.70f),
    roseGold = OnlyUsPalette.RoseGold500,
    roseGoldLight = OnlyUsPalette.RoseGold300,
    heartRoseGoldStart = Color(0xFFF4CFC4),
    heartRoseGoldEnd = Color(0xFFC98089),
    heartBurgundyStart = Color(0xFFB03A5C),
    heartBurgundyEnd = Color(0xFF6E1B36),
    wordmarkStart = OnlyUsPalette.Burgundy700,
    wordmarkEnd = OnlyUsPalette.RoseGold700,
    halo = OnlyUsPalette.RoseGold300.copy(alpha = 0.35f),
    logoDiscTop = Color.White.copy(alpha = 0.80f),
    logoDiscBottom = Color.White.copy(alpha = 0.55f),
    success = Color(0xFF2F6B4F),
    onSuccess = Color.White,
    successContainer = Color(0xFFD9EEE0),
    onSuccessContainer = Color(0xFF0E2E1E),
    illustrationBackdrop = OnlyUsPalette.Blush100.copy(alpha = 0.65f),
    floatingHearts = listOf(OnlyUsPalette.RoseGold300, OnlyUsPalette.Blush200, OnlyUsPalette.RoseGold500, Color.White),
)

internal val DarkBrandColors = BrandColors(
    backgroundTop = OnlyUsPalette.Charcoal900,
    backgroundMid = OnlyUsPalette.Plum900,
    backgroundBottom = OnlyUsPalette.PlumDeep,
    splashTop = OnlyUsPalette.Charcoal900,
    splashMid = Color(0xFF2A1824),
    splashBottom = Color(0xFF4A1B31),
    orbPrimary = OnlyUsPalette.Burgundy600.copy(alpha = 0.28f),
    orbSecondary = OnlyUsPalette.Champagne.copy(alpha = 0.10f),
    actionStart = Color(0xFFF0B3C0),
    actionEnd = Color(0xFFD98FA2),
    onAction = Color(0xFF3A0C1A),
    actionBorder = Color.White.copy(alpha = 0.35f),
    roseGold = Color(0xFFD4A09A),
    roseGoldLight = OnlyUsPalette.Champagne,
    heartRoseGoldStart = Color(0xFFF8D8CE),
    heartRoseGoldEnd = Color(0xFFD48E94),
    heartBurgundyStart = Color(0xFFD0607F),
    heartBurgundyEnd = OnlyUsPalette.Burgundy600,
    wordmarkStart = Color(0xFFF2C0CB),
    wordmarkEnd = OnlyUsPalette.Champagne,
    halo = Color(0xFFD4A09A).copy(alpha = 0.25f),
    logoDiscTop = Color.White.copy(alpha = 0.12f),
    logoDiscBottom = Color.White.copy(alpha = 0.06f),
    success = Color(0xFF9BD3B1),
    onSuccess = Color(0xFF0F3823),
    successContainer = Color(0xFF1F4B35),
    onSuccessContainer = Color(0xFFC2F0D2),
    illustrationBackdrop = Color.White.copy(alpha = 0.06f),
    floatingHearts = listOf(OnlyUsPalette.Champagne, OnlyUsPalette.MutedRose, OnlyUsPalette.Blush200, Color.White),
)
