package com.onlyus.app.core.designsystem.components

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.onlyus.app.core.designsystem.theme.OnlyUsRadius
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

private const val PressedCardScale = 0.985f

/**
 * A translucent glass card. Give it [onClick] and it becomes pressable: a gentle scale, a ripple, and a size change
 * that animates smoothly when its content grows or shrinks.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    onClickLabel: String? = null,
    shape: Shape = RoundedCornerShape(OnlyUsRadius.lg),
    strength: GlassStrength = GlassStrength.Regular,
    contentPadding: PaddingValues = PaddingValues(OnlyUsTheme.spacing.lg),
    content: @Composable ColumnScope.() -> Unit,
) {
    val glass = OnlyUsTheme.glass
    val effects = OnlyUsTheme.effects
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale = animateFloatAsState(
        targetValue = if (pressed && onClick != null && !effects.reducedMotion) PressedCardScale else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
        label = "glassCardScale",
    )

    Column(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            }
            .glassSurface(shape = shape, glass = glass, effects = effects, strength = strength)
            .clip(shape)
            .then(if (effects.reducedMotion) Modifier else Modifier.animateContentSize())
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = ripple(),
                        onClickLabel = onClickLabel,
                        role = Role.Button,
                        onClick = onClick,
                    )
                } else {
                    Modifier
                },
            )
            .padding(contentPadding),
        content = content,
    )
}

/**
 * A solid, ivory-paper card with a hairline border and a soft shadow that lowers while pressed.
 * Use it where content needs the calmest possible background, such as long text, forms and lists.
 */
@Composable
fun PremiumCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    onClickLabel: String? = null,
    shape: Shape = RoundedCornerShape(OnlyUsRadius.lg),
    contentPadding: PaddingValues = PaddingValues(OnlyUsTheme.spacing.lg),
    content: @Composable ColumnScope.() -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val glass = OnlyUsTheme.glass
    val effects = OnlyUsTheme.effects
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val pressable = onClick != null && !effects.reducedMotion
    val scale = animateFloatAsState(
        targetValue = if (pressed && pressable) PressedCardScale else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
        label = "premiumCardScale",
    )
    val elevation by animateDpAsState(
        targetValue = if (pressed && pressable) 2.dp else 8.dp,
        label = "premiumCardElevation",
    )

    Column(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            }
            .then(
                if (effects.reducedEffects) {
                    Modifier
                } else {
                    Modifier.shadow(
                        elevation = elevation,
                        shape = shape,
                        clip = false,
                        ambientColor = glass.shadow,
                        spotColor = glass.shadow,
                    )
                },
            )
            .background(scheme.surface, shape)
            .border(1.dp, if (effects.reducedEffects) glass.flatBorder else scheme.outlineVariant, shape)
            .clip(shape)
            .then(if (effects.reducedMotion) Modifier else Modifier.animateContentSize())
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = ripple(),
                        onClickLabel = onClickLabel,
                        role = Role.Button,
                        onClick = onClick,
                    )
                } else {
                    Modifier
                },
            )
            .padding(contentPadding),
        content = content,
    )
}
