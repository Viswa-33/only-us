package com.onlyus.app.core.designsystem.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

/*
 * Light and dark are two complete sets of tokens. To switch between them smoothly, OnlyUsTheme animates one
 * progress value from 0 (light) to 1 (dark) and blends every colour at that progress.
 * At exactly 0 or 1 the original, unblended token sets are used, so a settled theme allocates nothing extra.
 */

internal fun themedColorScheme(progress: Float): ColorScheme = when {
    progress <= 0f -> LightColorScheme
    progress >= 1f -> DarkColorScheme
    else -> lerpColorScheme(LightColorScheme, DarkColorScheme, progress)
}

internal fun themedGlassColors(progress: Float): GlassColors = when {
    progress <= 0f -> LightGlassColors
    progress >= 1f -> DarkGlassColors
    else -> lerpGlassColors(LightGlassColors, DarkGlassColors, progress)
}

internal fun themedBrandColors(progress: Float): BrandColors = when {
    progress <= 0f -> LightBrandColors
    progress >= 1f -> DarkBrandColors
    else -> lerpBrandColors(LightBrandColors, DarkBrandColors, progress)
}

internal fun lerpColorScheme(start: ColorScheme, stop: ColorScheme, fraction: Float): ColorScheme {
    fun mix(a: Color, b: Color) = lerp(a, b, fraction)
    return start.copy(
        primary = mix(start.primary, stop.primary),
        onPrimary = mix(start.onPrimary, stop.onPrimary),
        primaryContainer = mix(start.primaryContainer, stop.primaryContainer),
        onPrimaryContainer = mix(start.onPrimaryContainer, stop.onPrimaryContainer),
        inversePrimary = mix(start.inversePrimary, stop.inversePrimary),
        secondary = mix(start.secondary, stop.secondary),
        onSecondary = mix(start.onSecondary, stop.onSecondary),
        secondaryContainer = mix(start.secondaryContainer, stop.secondaryContainer),
        onSecondaryContainer = mix(start.onSecondaryContainer, stop.onSecondaryContainer),
        tertiary = mix(start.tertiary, stop.tertiary),
        onTertiary = mix(start.onTertiary, stop.onTertiary),
        tertiaryContainer = mix(start.tertiaryContainer, stop.tertiaryContainer),
        onTertiaryContainer = mix(start.onTertiaryContainer, stop.onTertiaryContainer),
        background = mix(start.background, stop.background),
        onBackground = mix(start.onBackground, stop.onBackground),
        surface = mix(start.surface, stop.surface),
        onSurface = mix(start.onSurface, stop.onSurface),
        surfaceVariant = mix(start.surfaceVariant, stop.surfaceVariant),
        onSurfaceVariant = mix(start.onSurfaceVariant, stop.onSurfaceVariant),
        surfaceTint = mix(start.surfaceTint, stop.surfaceTint),
        inverseSurface = mix(start.inverseSurface, stop.inverseSurface),
        inverseOnSurface = mix(start.inverseOnSurface, stop.inverseOnSurface),
        error = mix(start.error, stop.error),
        onError = mix(start.onError, stop.onError),
        errorContainer = mix(start.errorContainer, stop.errorContainer),
        onErrorContainer = mix(start.onErrorContainer, stop.onErrorContainer),
        outline = mix(start.outline, stop.outline),
        outlineVariant = mix(start.outlineVariant, stop.outlineVariant),
        scrim = mix(start.scrim, stop.scrim),
        surfaceBright = mix(start.surfaceBright, stop.surfaceBright),
        surfaceDim = mix(start.surfaceDim, stop.surfaceDim),
        surfaceContainer = mix(start.surfaceContainer, stop.surfaceContainer),
        surfaceContainerHigh = mix(start.surfaceContainerHigh, stop.surfaceContainerHigh),
        surfaceContainerHighest = mix(start.surfaceContainerHighest, stop.surfaceContainerHighest),
        surfaceContainerLow = mix(start.surfaceContainerLow, stop.surfaceContainerLow),
        surfaceContainerLowest = mix(start.surfaceContainerLowest, stop.surfaceContainerLowest),
    )
}

internal fun lerpGlassColors(start: GlassColors, stop: GlassColors, fraction: Float): GlassColors {
    fun mix(a: Color, b: Color) = lerp(a, b, fraction)
    return GlassColors(
        fillTop = mix(start.fillTop, stop.fillTop),
        fillBottom = mix(start.fillBottom, stop.fillBottom),
        strongFillTop = mix(start.strongFillTop, stop.strongFillTop),
        strongFillBottom = mix(start.strongFillBottom, stop.strongFillBottom),
        borderStart = mix(start.borderStart, stop.borderStart),
        borderEnd = mix(start.borderEnd, stop.borderEnd),
        sheen = mix(start.sheen, stop.sheen),
        shadow = mix(start.shadow, stop.shadow),
        selectionFill = mix(start.selectionFill, stop.selectionFill),
        selectionBorder = mix(start.selectionBorder, stop.selectionBorder),
        flatFill = mix(start.flatFill, stop.flatFill),
        flatBorder = mix(start.flatBorder, stop.flatBorder),
    )
}

internal fun lerpBrandColors(start: BrandColors, stop: BrandColors, fraction: Float): BrandColors {
    fun mix(a: Color, b: Color) = lerp(a, b, fraction)
    val hearts = List(start.floatingHearts.size) { i ->
        mix(start.floatingHearts[i], stop.floatingHearts[minOf(i, stop.floatingHearts.lastIndex)])
    }
    return BrandColors(
        backgroundTop = mix(start.backgroundTop, stop.backgroundTop),
        backgroundMid = mix(start.backgroundMid, stop.backgroundMid),
        backgroundBottom = mix(start.backgroundBottom, stop.backgroundBottom),
        splashTop = mix(start.splashTop, stop.splashTop),
        splashMid = mix(start.splashMid, stop.splashMid),
        splashBottom = mix(start.splashBottom, stop.splashBottom),
        orbPrimary = mix(start.orbPrimary, stop.orbPrimary),
        orbSecondary = mix(start.orbSecondary, stop.orbSecondary),
        actionStart = mix(start.actionStart, stop.actionStart),
        actionEnd = mix(start.actionEnd, stop.actionEnd),
        onAction = mix(start.onAction, stop.onAction),
        actionBorder = mix(start.actionBorder, stop.actionBorder),
        roseGold = mix(start.roseGold, stop.roseGold),
        roseGoldLight = mix(start.roseGoldLight, stop.roseGoldLight),
        heartRoseGoldStart = mix(start.heartRoseGoldStart, stop.heartRoseGoldStart),
        heartRoseGoldEnd = mix(start.heartRoseGoldEnd, stop.heartRoseGoldEnd),
        heartBurgundyStart = mix(start.heartBurgundyStart, stop.heartBurgundyStart),
        heartBurgundyEnd = mix(start.heartBurgundyEnd, stop.heartBurgundyEnd),
        wordmarkStart = mix(start.wordmarkStart, stop.wordmarkStart),
        wordmarkEnd = mix(start.wordmarkEnd, stop.wordmarkEnd),
        halo = mix(start.halo, stop.halo),
        logoDiscTop = mix(start.logoDiscTop, stop.logoDiscTop),
        logoDiscBottom = mix(start.logoDiscBottom, stop.logoDiscBottom),
        success = mix(start.success, stop.success),
        onSuccess = mix(start.onSuccess, stop.onSuccess),
        successContainer = mix(start.successContainer, stop.successContainer),
        onSuccessContainer = mix(start.onSuccessContainer, stop.onSuccessContainer),
        illustrationBackdrop = mix(start.illustrationBackdrop, stop.illustrationBackdrop),
        floatingHearts = hearts,
    )
}
