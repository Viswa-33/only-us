package com.onlyus.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.onlyus.app.ui.OnlyUsApp
import dagger.hilt.android.AndroidEntryPoint

/** The only activity. Everything else is a Compose destination. */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Draw behind the status and navigation bars; every screen handles its own insets.
        WindowCompat.enableEdgeToEdge(window)

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            when (val current = state) {
                // The window background (same colour as the system splash) covers the few milliseconds it takes
                // to read the saved settings, so there is no flash of the wrong theme.
                MainUiState.Loading -> Unit
                is MainUiState.Ready -> OnlyUsApp(themeMode = current.themeMode, effects = current.effects)
            }
        }
    }
}
