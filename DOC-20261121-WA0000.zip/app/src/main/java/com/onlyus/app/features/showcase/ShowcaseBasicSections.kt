package com.onlyus.app.features.showcase

import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.components.GlassCard
import com.onlyus.app.core.designsystem.components.GlassChip
import com.onlyus.app.core.designsystem.components.GlassStrength
import com.onlyus.app.core.designsystem.components.OnlyUsDivider
import com.onlyus.app.core.designsystem.components.OrnamentDivider
import com.onlyus.app.core.designsystem.components.PremiumCard
import com.onlyus.app.core.designsystem.theme.EffectsMode
import com.onlyus.app.core.designsystem.theme.OnlyUsRadius
import com.onlyus.app.core.designsystem.theme.OnlyUsTextStyles
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme
import com.onlyus.app.core.preferences.ThemeMode
import java.util.Locale

/*
 * The foundations half of the gallery: the introduction, the appearance switches, typography and colour.
 * All text here comes from strings.xml and all styling from the theme; nothing is hard-coded.
 */

@Composable
internal fun IntroSection() {
    val scheme = MaterialTheme.colorScheme
    val spacing = OnlyUsTheme.spacing

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        strength = GlassStrength.Strong,
        contentPadding = PaddingValues(spacing.xl),
    ) {
        Text(
            text = stringResource(R.string.showcase_intro_overline),
            style = OnlyUsTextStyles.Overline,
            color = scheme.secondary,
        )
        Spacer(Modifier.height(spacing.sm))
        Text(
            text = stringResource(R.string.showcase_intro_title),
            style = MaterialTheme.typography.headlineMedium,
            color = scheme.onSurface,
            modifier = Modifier.semantics { heading() },
        )
        Spacer(Modifier.height(spacing.md))
        Text(
            text = stringResource(R.string.showcase_intro_body),
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(spacing.lg))
        OrnamentDivider()
        Spacer(Modifier.height(spacing.sm))
        Text(
            text = stringResource(R.string.sample_handwritten_accent),
            style = OnlyUsTextStyles.HandwrittenAccent,
            color = scheme.primary,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
    }
}

@Composable
internal fun AppearanceSection(
    appearance: AppearanceState,
    onThemeModeChange: (ThemeMode) -> Unit,
    onEffectsModeChange: (EffectsMode) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme

    ShowcaseSection(
        title = stringResource(R.string.showcase_appearance_title),
        overline = stringResource(R.string.showcase_overline_foundations),
        hint = stringResource(R.string.showcase_appearance_hint),
    ) {
        ChipGroup(label = stringResource(R.string.appearance_theme_label)) {
            ThemeMode.entries.forEach { mode ->
                GlassChip(
                    text = stringResource(mode.labelRes()),
                    selected = appearance.themeMode == mode,
                    onClick = { onThemeModeChange(mode) },
                )
            }
        }
        ChipGroup(label = stringResource(R.string.appearance_effects_label)) {
            EffectsMode.entries.forEach { mode ->
                GlassChip(
                    text = stringResource(mode.labelRes()),
                    selected = appearance.effectsMode == mode,
                    onClick = { onEffectsModeChange(mode) },
                )
            }
        }
        Text(
            text = stringResource(R.string.appearance_effects_hint),
            style = MaterialTheme.typography.bodySmall,
            color = scheme.onSurfaceVariant,
        )
    }
}

/** A label and a row of chips announced as one radio group. The row scrolls sideways at very large font sizes. */
@Composable
private fun ChipGroup(
    label: String,
    content: @Composable RowScope.() -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.xs)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .selectableGroup(),
            horizontalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.sm),
            content = content,
        )
    }
}

@StringRes
private fun ThemeMode.labelRes(): Int = when (this) {
    ThemeMode.SYSTEM -> R.string.theme_system
    ThemeMode.LIGHT -> R.string.theme_light
    ThemeMode.DARK -> R.string.theme_dark
}

@StringRes
private fun EffectsMode.labelRes(): Int = when (this) {
    EffectsMode.AUTO -> R.string.effects_auto
    EffectsMode.FULL -> R.string.effects_full
    EffectsMode.REDUCED -> R.string.effects_reduced
}

private class TypeSample(
    @StringRes val name: Int,
    @StringRes val text: Int,
    @StringRes val family: Int,
    val style: TextStyle,
)

@Composable
internal fun TypographySection() {
    val typography = MaterialTheme.typography
    val scheme = MaterialTheme.colorScheme
    val spacing = OnlyUsTheme.spacing

    val samples = listOf(
        TypeSample(R.string.type_display_large, R.string.sample_display_large, R.string.font_playfair, typography.displayLarge),
        TypeSample(R.string.type_display_medium, R.string.sample_display_medium, R.string.font_playfair, typography.displayMedium),
        TypeSample(R.string.type_headline_large, R.string.sample_headline_large, R.string.font_playfair, typography.headlineLarge),
        TypeSample(R.string.type_headline_medium, R.string.sample_headline_medium, R.string.font_playfair, typography.headlineMedium),
        TypeSample(R.string.type_title_large, R.string.sample_title_large, R.string.font_playfair, typography.titleLarge),
        TypeSample(R.string.type_title_medium, R.string.sample_title_medium, R.string.font_poppins, typography.titleMedium),
        TypeSample(R.string.type_body_large, R.string.sample_body_large, R.string.font_poppins, typography.bodyLarge),
        TypeSample(R.string.type_body_medium, R.string.sample_body_medium, R.string.font_poppins, typography.bodyMedium),
        TypeSample(R.string.type_label_large, R.string.sample_label_large, R.string.font_poppins, typography.labelLarge),
        TypeSample(R.string.type_romantic_quote, R.string.sample_romantic_quote, R.string.font_playfair, OnlyUsTextStyles.RomanticQuote),
        TypeSample(R.string.type_handwritten_accent, R.string.sample_handwritten_accent, R.string.font_great_vibes, OnlyUsTextStyles.HandwrittenAccent),
    )

    ShowcaseSection(
        title = stringResource(R.string.showcase_typography_title),
        overline = stringResource(R.string.showcase_overline_foundations),
        hint = stringResource(R.string.showcase_typography_hint),
    ) {
        PremiumCard(modifier = Modifier.fillMaxWidth()) {
            samples.forEachIndexed { index, sample ->
                if (index > 0) {
                    Spacer(Modifier.height(spacing.md))
                    OnlyUsDivider()
                    Spacer(Modifier.height(spacing.md))
                }
                Text(
                    text = stringResource(sample.name),
                    style = typography.labelLarge,
                    color = scheme.secondary,
                )
                Text(
                    text = stringResource(
                        R.string.type_spec,
                        stringResource(sample.family),
                        sample.style.fontSize.value.toInt(),
                        sample.style.lineHeight.value.toInt(),
                    ),
                    style = typography.labelSmall,
                    color = scheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(spacing.xs))
                Text(
                    text = stringResource(sample.text),
                    style = sample.style,
                    color = scheme.onSurface,
                )
            }
        }
    }
}

private class Swatch(
    @StringRes val name: Int,
    val color: Color,
    val onColor: Color?,
)

@Composable
internal fun PaletteSection() {
    val scheme = MaterialTheme.colorScheme
    val brand = OnlyUsTheme.brand
    val spacing = OnlyUsTheme.spacing
    val shape = RoundedCornerShape(OnlyUsRadius.md)

    val swatches = listOf(
        Swatch(R.string.color_primary, scheme.primary, scheme.onPrimary),
        Swatch(R.string.color_primary_container, scheme.primaryContainer, scheme.onPrimaryContainer),
        Swatch(R.string.color_secondary, scheme.secondary, scheme.onSecondary),
        Swatch(R.string.color_tertiary, scheme.tertiary, scheme.onTertiary),
        Swatch(R.string.color_background, scheme.background, scheme.onBackground),
        Swatch(R.string.color_surface, scheme.surfaceContainer, scheme.onSurface),
        Swatch(R.string.color_error, scheme.error, scheme.onError),
        Swatch(R.string.color_success, brand.success, brand.onSuccess),
        Swatch(R.string.color_rose_gold, brand.roseGold, null),
        Swatch(R.string.color_outline, scheme.outline, null),
    )

    ShowcaseSection(
        title = stringResource(R.string.showcase_palette_title),
        overline = stringResource(R.string.showcase_overline_foundations),
        hint = stringResource(R.string.showcase_palette_hint),
    ) {
        // The signature gradient used by primary buttons.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp)
                .clip(shape)
                .background(brand.actionBrush)
                .border(1.dp, brand.actionBorder, shape)
                .clearAndSetSemantics { },
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(R.string.color_action_gradient),
                style = MaterialTheme.typography.titleMedium,
                color = brand.onAction,
            )
        }

        swatches.chunked(2).forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(spacing.md),
            ) {
                pair.forEach { swatch -> SwatchCell(swatch = swatch, modifier = Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun SwatchCell(
    swatch: Swatch,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(OnlyUsRadius.md)

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.xs),
    ) {
        // The "Aa" shows the matching on-colour on this colour. It is decoration: the name and value below say it all.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .clip(shape)
                .background(swatch.color)
                .border(1.dp, scheme.outlineVariant, shape)
                .clearAndSetSemantics { },
            contentAlignment = Alignment.Center,
        ) {
            if (swatch.onColor != null) {
                Text(
                    text = stringResource(R.string.sample_aa),
                    style = MaterialTheme.typography.headlineSmall,
                    color = swatch.onColor,
                )
            }
        }
        Text(
            text = stringResource(swatch.name),
            style = MaterialTheme.typography.labelLarge,
            color = scheme.onBackground,
        )
        Text(
            text = hexOf(swatch.color),
            style = MaterialTheme.typography.labelSmall,
            color = scheme.onSurfaceVariant,
        )
    }
}

private fun hexOf(color: Color): String = String.format(Locale.ROOT, "#%06X", color.toArgb() and 0xFFFFFF)
