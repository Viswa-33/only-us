package com.onlyus.app.features.showcase

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.PreviewLightDark
import com.onlyus.app.core.designsystem.components.OnlyUsBackground
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

/*
 * Android Studio previews of the design system, each in light and dark. Open this file and switch to Split or Design
 * view to see them without running the app.
 *
 * They reuse the very same sections as the in-app gallery, so the previews and the gallery cannot drift apart.
 * Previews are developer tooling only: R8 removes them from release builds, and they add no dependency beyond the
 * tooling libraries the project already declares.
 */

/** The theme and the shared background around one preview, using whichever mode the preview asks for. */
@Composable
private fun PreviewFrame(content: @Composable () -> Unit) {
    OnlyUsTheme(darkTheme = isSystemInDarkTheme()) {
        OnlyUsBackground(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(
                    horizontal = OnlyUsTheme.spacing.screenHorizontal,
                    vertical = OnlyUsTheme.spacing.xl,
                ),
            ) {
                content()
            }
        }
    }
}

@PreviewLightDark
@Composable
private fun TypographyPreview() = PreviewFrame { TypographySection() }

@PreviewLightDark
@Composable
private fun PalettePreview() = PreviewFrame { PaletteSection() }

@PreviewLightDark
@Composable
private fun ButtonsPreview() = PreviewFrame { ButtonsSection() }

@PreviewLightDark
@Composable
private fun IconButtonsPreview() = PreviewFrame { IconButtonsSection() }

@PreviewLightDark
@Composable
private fun CardsPreview() = PreviewFrame { CardsSection() }

@PreviewLightDark
@Composable
private fun ProfilesPreview() = PreviewFrame { ProfilesSection() }

@PreviewLightDark
@Composable
private fun FieldsPreview() = PreviewFrame { FieldsSection() }

@PreviewLightDark
@Composable
private fun FeedbackPreview() = PreviewFrame { FeedbackSection() }

@PreviewLightDark
@Composable
private fun DividersPreview() = PreviewFrame { DividersSection() }

@PreviewLightDark
@Composable
private fun EmptyStatePreview() = PreviewFrame { EmptyStateSection() }
