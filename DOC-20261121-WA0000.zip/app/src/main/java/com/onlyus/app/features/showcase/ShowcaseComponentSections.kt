package com.onlyus.app.features.showcase

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.components.CoupleCard
import com.onlyus.app.core.designsystem.components.GlassButton
import com.onlyus.app.core.designsystem.components.GlassButtonStyle
import com.onlyus.app.core.designsystem.components.GlassCard
import com.onlyus.app.core.designsystem.components.IconButtonStyle
import com.onlyus.app.core.designsystem.components.NotificationBadge
import com.onlyus.app.core.designsystem.components.OnlyUsIconButton
import com.onlyus.app.core.designsystem.components.PremiumCard
import com.onlyus.app.core.designsystem.components.ProfileCard
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/*
 * The components half of the gallery, part one: buttons, icon buttons, cards and profile cards.
 * Taps on the sample buttons do nothing on purpose except where a demo says otherwise: they exist to show the press
 * feedback (soft scale and ripple).
 */

private const val LoadingDemoMillis = 1800L

@Composable
internal fun ButtonsSection() {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }

    ShowcaseSection(
        title = stringResource(R.string.showcase_buttons_title),
        overline = stringResource(R.string.showcase_overline_components),
        hint = stringResource(R.string.showcase_buttons_hint),
    ) {
        GlassButton(
            text = stringResource(R.string.button_primary),
            onClick = {},
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = R.drawable.ic_arrow_forward,
        )
        GlassButton(
            text = stringResource(R.string.button_loading),
            onClick = {
                if (!loading) {
                    loading = true
                    scope.launch {
                        delay(LoadingDemoMillis)
                        loading = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            loading = loading,
            leadingIcon = R.drawable.ic_heart_filled,
        )
        GlassButton(
            text = stringResource(R.string.button_secondary),
            onClick = {},
            modifier = Modifier.fillMaxWidth(),
            style = GlassButtonStyle.Secondary,
        )
        GlassButton(
            text = stringResource(R.string.button_text),
            onClick = {},
            modifier = Modifier.fillMaxWidth(),
            style = GlassButtonStyle.Text,
        )
        GlassButton(
            text = stringResource(R.string.button_disabled),
            onClick = {},
            modifier = Modifier.fillMaxWidth(),
            enabled = false,
        )
    }
}

@Composable
internal fun IconButtonsSection() {
    val spacing = OnlyUsTheme.spacing
    var count by rememberSaveable { mutableIntStateOf(2) }

    ShowcaseSection(
        title = stringResource(R.string.showcase_icon_buttons_title),
        overline = stringResource(R.string.showcase_overline_components),
        hint = stringResource(R.string.showcase_icon_buttons_hint),
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(spacing.xl),
            verticalAlignment = Alignment.Top,
        ) {
            IconButtonSample(label = stringResource(R.string.icon_style_plain)) {
                OnlyUsIconButton(
                    icon = R.drawable.ic_heart_outline,
                    contentDescription = stringResource(R.string.action_favorite),
                    onClick = {},
                    style = IconButtonStyle.Plain,
                )
            }
            IconButtonSample(label = stringResource(R.string.icon_style_tonal)) {
                OnlyUsIconButton(
                    icon = R.drawable.ic_search,
                    contentDescription = stringResource(R.string.action_search),
                    onClick = {},
                    style = IconButtonStyle.Tonal,
                )
            }
            IconButtonSample(label = stringResource(R.string.icon_style_glass)) {
                OnlyUsIconButton(
                    icon = R.drawable.ic_more_horiz,
                    contentDescription = stringResource(R.string.action_more),
                    onClick = {},
                    style = IconButtonStyle.Glass,
                )
            }
            IconButtonSample(label = stringResource(R.string.icon_style_badge)) {
                OnlyUsIconButton(
                    icon = R.drawable.ic_notifications,
                    contentDescription = stringResource(R.string.action_notifications),
                    onClick = { count += 1 },
                    style = IconButtonStyle.Glass,
                    badge = { NotificationBadge(count = count, modifier = Modifier.align(Alignment.TopEnd)) },
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(spacing.sm)) {
            GlassButton(
                text = stringResource(R.string.button_clear_badge),
                onClick = { count = 0 },
                style = GlassButtonStyle.Text,
                enabled = count > 0,
            )
        }
    }
}

/** An icon button with a small caption underneath, for lining up the styles side by side. */
@Composable
private fun IconButtonSample(
    label: String,
    content: @Composable () -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.xs),
    ) {
        content()
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
internal fun CardsSection() {
    val scheme = MaterialTheme.colorScheme
    val spacing = OnlyUsTheme.spacing
    val reducedMotion = OnlyUsTheme.effects.reducedMotion
    var expanded by rememberSaveable { mutableStateOf(false) }

    ShowcaseSection(
        title = stringResource(R.string.showcase_cards_title),
        overline = stringResource(R.string.showcase_overline_components),
        hint = stringResource(R.string.showcase_cards_hint),
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (reducedMotion) Modifier else Modifier.animateContentSize()),
            onClick = { expanded = !expanded },
            onClickLabel = stringResource(R.string.card_toggle_label),
        ) {
            Text(
                text = stringResource(R.string.card_glass_title),
                style = MaterialTheme.typography.titleLarge,
                color = scheme.onSurface,
            )
            Spacer(Modifier.height(spacing.sm))
            Text(
                text = stringResource(R.string.card_glass_body),
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
            )
            if (expanded) {
                Spacer(Modifier.height(spacing.sm))
                Text(
                    text = stringResource(R.string.card_glass_extra),
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant,
                )
            }
        }

        PremiumCard(
            modifier = Modifier.fillMaxWidth(),
            onClick = {},
        ) {
            Text(
                text = stringResource(R.string.card_premium_title),
                style = MaterialTheme.typography.titleLarge,
                color = scheme.onSurface,
            )
            Spacer(Modifier.height(spacing.sm))
            Text(
                text = stringResource(R.string.card_premium_body),
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
internal fun ProfilesSection() {
    val scheme = MaterialTheme.colorScheme

    ShowcaseSection(
        title = stringResource(R.string.showcase_profiles_title),
        overline = stringResource(R.string.showcase_overline_components),
        hint = stringResource(R.string.showcase_profiles_hint),
    ) {
        ProfileCard(
            name = stringResource(R.string.sample_name_one),
            subtitle = stringResource(R.string.sample_status_online),
            modifier = Modifier.fillMaxWidth(),
            online = true,
            onClick = {},
            trailing = {
                Icon(
                    painter = painterResource(R.drawable.ic_arrow_forward),
                    contentDescription = null,
                    tint = scheme.onSurfaceVariant,
                )
            },
        )
        ProfileCard(
            name = stringResource(R.string.sample_name_two),
            subtitle = stringResource(R.string.sample_status_away),
            modifier = Modifier.fillMaxWidth(),
            online = false,
        )
        CoupleCard(
            firstName = stringResource(R.string.sample_first_name_one),
            secondName = stringResource(R.string.sample_first_name_two),
            caption = stringResource(R.string.app_tagline),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
