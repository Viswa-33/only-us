package com.onlyus.app.core.designsystem.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.onlyus.app.core.designsystem.theme.OnlyUsTextStyles
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

/** A hairline in rose gold that fades out at both ends. Purely decorative. */
@Composable
fun OnlyUsDivider(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(OnlyUsTheme.brand.dividerBrush),
    )
}

/** Two fading hairlines with a small rose-gold heart between them. Purely decorative. */
@Composable
fun OrnamentDivider(modifier: Modifier = Modifier) {
    val brand = OnlyUsTheme.brand
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.md),
    ) {
        Box(Modifier.weight(1f).height(1.dp).background(brand.dividerFadeInBrush))
        HeartIcon(size = 10.dp)
        Box(Modifier.weight(1f).height(1.dp).background(brand.dividerFadeOutBrush))
    }
}

/**
 * A section title: an optional small overline, a Playfair Display heading, an optional description, and an optional
 * action (for example a "See all" button) aligned to the end. The title is announced as a heading.
 */
@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    overline: String? = null,
    subtitle: String? = null,
    action: (@Composable () -> Unit)? = null,
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.md),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            if (overline != null) {
                Text(
                    text = overline,
                    style = OnlyUsTextStyles.Overline,
                    color = scheme.secondary,
                    modifier = Modifier.padding(bottom = OnlyUsTheme.spacing.xs),
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = scheme.onBackground,
                modifier = Modifier.semantics { heading() },
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = OnlyUsTheme.spacing.xs),
                )
            }
        }
        action?.invoke()
    }
}
