package com.onlyus.app.core.designsystem.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.onlyus.app.core.designsystem.theme.GlassColors
import com.onlyus.app.core.designsystem.theme.OnlyUsEffects

object GlassDefaults {
    val BorderWidth: Dp = 1.dp
    val CardElevation: Dp = 10.dp
    val ControlElevation: Dp = 5.dp
}

/** Strong glass is more opaque. Use it for controls and bars that sit over busy content. */
enum class GlassStrength { Regular, Strong }

/**
 * The one place that draws "glass". Nothing here blurs what is behind it, which keeps scrolling smooth on every phone:
 * a translucent gradient fill, a faint top sheen, a thin luminous border and a soft tinted shadow.
 *
 * With reduced effects it becomes a flat themed surface with a plain border: no shadow, no sheen, no gradient.
 *
 * It does not clip the content. Callers add `.clip(shape)` after it when content or a ripple must follow the corners.
 * It is a plain function, not a composable, so callers read the theme once and pass the tokens in.
 */
fun Modifier.glassSurface(
    shape: Shape,
    glass: GlassColors,
    effects: OnlyUsEffects,
    strength: GlassStrength = GlassStrength.Regular,
    elevation: Dp = GlassDefaults.CardElevation,
    borderWidth: Dp = GlassDefaults.BorderWidth,
    borderBrush: Brush? = null,
): Modifier = if (effects.reducedEffects) {
    this
        .background(glass.flatFill, shape)
        .border(borderWidth, borderBrush ?: Brush.linearGradient(listOf(glass.flatBorder, glass.flatBorder)), shape)
} else {
    this
        .shadow(elevation, shape, clip = false, ambientColor = glass.shadow, spotColor = glass.shadow)
        .background(if (strength == GlassStrength.Strong) glass.strongFill else glass.fill, shape)
        .background(glass.sheenBrush, shape)
        .border(borderWidth, borderBrush ?: glass.border, shape)
}
