package com.onlyus.app.core.designsystem.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.error
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.theme.OnlyUsRadius
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

enum class FieldStatus { Default, Error, Success }

private const val DisabledAlpha = 0.38f

/**
 * The Only Us text field: a glass-tinted outlined field with a floating label that rises when the field is focused
 * or filled. It has clear focused, error, success and disabled states, never relying on colour alone: an error or
 * success is also spelled out in [supportingText], and an error is announced by screen readers.
 *
 * With [isPassword] it hides the text and shows a show/hide toggle.
 *
 * Built on Material 3's value-based OutlinedTextField. Newer Material 3 releases prefer the TextFieldState overload and
 * mark this one deprecated (a warning only), so the deprecation is suppressed here, in one place.
 */
@Suppress("DEPRECATION")
@Composable
fun OnlyUsTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    status: FieldStatus = FieldStatus.Default,
    supportingText: String? = null,
    @DrawableRes leadingIcon: Int? = null,
    isPassword: Boolean = false,
    singleLine: Boolean = true,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
) {
    val scheme = MaterialTheme.colorScheme
    val glass = OnlyUsTheme.glass
    val brand = OnlyUsTheme.brand
    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    val showPassword = isPassword && passwordVisible

    val accent = when (status) {
        FieldStatus.Error -> scheme.error
        FieldStatus.Success -> brand.success
        FieldStatus.Default -> scheme.primary
    }
    val resting = if (status == FieldStatus.Success) brand.success else scheme.onSurfaceVariant
    val colors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = scheme.onSurface,
        unfocusedTextColor = scheme.onSurface,
        disabledTextColor = scheme.onSurface.copy(alpha = DisabledAlpha),
        errorTextColor = scheme.onSurface,
        focusedContainerColor = glass.selectionFill,
        unfocusedContainerColor = glass.strongFillBottom,
        disabledContainerColor = scheme.onSurface.copy(alpha = 0.04f),
        errorContainerColor = glass.strongFillBottom,
        cursorColor = accent,
        errorCursorColor = scheme.error,
        focusedBorderColor = accent,
        unfocusedBorderColor = if (status == FieldStatus.Success) brand.success else scheme.outline,
        disabledBorderColor = scheme.onSurface.copy(alpha = 0.12f),
        errorBorderColor = scheme.error,
        focusedLeadingIconColor = accent,
        unfocusedLeadingIconColor = resting,
        disabledLeadingIconColor = scheme.onSurface.copy(alpha = DisabledAlpha),
        errorLeadingIconColor = scheme.error,
        focusedTrailingIconColor = accent,
        unfocusedTrailingIconColor = resting,
        disabledTrailingIconColor = scheme.onSurface.copy(alpha = DisabledAlpha),
        errorTrailingIconColor = scheme.error,
        focusedLabelColor = accent,
        unfocusedLabelColor = resting,
        disabledLabelColor = scheme.onSurface.copy(alpha = DisabledAlpha),
        errorLabelColor = scheme.error,
        focusedSupportingTextColor = if (status == FieldStatus.Success) brand.success else scheme.onSurfaceVariant,
        unfocusedSupportingTextColor = if (status == FieldStatus.Success) brand.success else scheme.onSurfaceVariant,
        disabledSupportingTextColor = scheme.onSurface.copy(alpha = DisabledAlpha),
        errorSupportingTextColor = scheme.error,
    )

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.semantics {
            if (status == FieldStatus.Error && supportingText != null) error(supportingText)
        },
        enabled = enabled,
        textStyle = MaterialTheme.typography.bodyLarge,
        label = { Text(text = label, maxLines = 1) },
        leadingIcon = if (leadingIcon != null) {
            { Icon(painter = painterResource(leadingIcon), contentDescription = null) }
        } else {
            null
        },
        trailingIcon = when {
            isPassword -> {
                {
                    OnlyUsIconButton(
                        icon = if (showPassword) R.drawable.ic_visibility_off else R.drawable.ic_visibility,
                        contentDescription = stringResource(
                            if (showPassword) R.string.action_hide_password else R.string.action_show_password,
                        ),
                        onClick = { passwordVisible = !passwordVisible },
                        enabled = enabled,
                        tint = resting,
                    )
                }
            }
            status == FieldStatus.Success -> {
                { Icon(painter = painterResource(R.drawable.ic_check), contentDescription = null) }
            }
            else -> null
        },
        supportingText = if (supportingText != null) {
            { Text(text = supportingText, style = MaterialTheme.typography.bodySmall) }
        } else {
            null
        },
        isError = status == FieldStatus.Error,
        visualTransformation = if (isPassword && !showPassword) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        singleLine = singleLine,
        shape = RoundedCornerShape(OnlyUsRadius.md),
        colors = colors,
    )
}
