package com.onlyus.app.core.designsystem.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.onlyus.app.core.designsystem.theme.OnlyUsShapes
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

/**
 * A pill that is either selected or not. Put several in a Row with `Modifier.selectableGroup()` so a screen reader
 * announces them as one radio group. The visible pill is 40dp tall inside a 48dp touch target.
 */
@Composable
fun GlassChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    @DrawableRes leadingIcon: Int? = null,
) {
    val scheme = MaterialTheme.colorScheme
    val glass = OnlyUsTheme.glass
    val effects = OnlyUsTheme.effects
    val spacing = OnlyUsTheme.spacing
    val shape = OnlyUsShapes.Pill
    val interactionSource = remember { MutableInteractionSource() }

    val container by animateColorAsState(
        targetValue = if (selected) scheme.primaryContainer else glass.strongFillBottom,
        label = "chipContainer",
    )
    val content by animateColorAsState(
        targetValue = if (selected) scheme.onPrimaryContainer else scheme.onSurface,
        label = "chipContent",
    )
    val border by animateColorAsState(
        targetValue = if (selected) scheme.primary else if (effects.reducedEffects) glass.flatBorder else scheme.outlineVariant,
        label = "chipBorder",
    )

    Row(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .height(40.dp)
            .clip(shape)
            .background(container, shape)
            .border(if (selected) 1.5.dp else 1.dp, border, shape)
            .selectable(
                selected = selected,
                interactionSource = interactionSource,
                indication = ripple(color = scheme.primary),
                role = Role.RadioButton,
                onClick = onClick,
            )
            .padding(horizontal = spacing.lg),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(spacing.sm, Alignment.CenterHorizontally),
    ) {
        if (leadingIcon != null) {
            Icon(painterResource(leadingIcon), contentDescription = null, modifier = Modifier.size(18.dp), tint = content)
        }
        Text(text = text, style = MaterialTheme.typography.labelLarge, color = content, maxLines = 1)
    }
}
