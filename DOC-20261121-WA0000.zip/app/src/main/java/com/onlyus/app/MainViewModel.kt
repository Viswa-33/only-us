package com.onlyus.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.onlyus.app.core.designsystem.theme.OnlyUsEffects
import com.onlyus.app.core.designsystem.theme.resolveEffects
import com.onlyus.app.core.device.DeviceCapabilities
import com.onlyus.app.core.preferences.AppPreferencesRepository
import com.onlyus.app.core.preferences.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

/** What the activity needs before it can draw anything: the theme choice and the resolved effects. */
sealed interface MainUiState {
    /** Settings are still being read from disk. The activity shows only the window background until they arrive. */
    data object Loading : MainUiState

    data class Ready(
        val themeMode: ThemeMode,
        val effects: OnlyUsEffects,
    ) : MainUiState
}

/**
 * Combines the saved choices (theme, effects mode) with live device facts (low RAM, Battery Saver, animation scale)
 * into one state for the whole app. The "effects" rule itself lives in [resolveEffects], where it is unit-testable.
 */
@HiltViewModel
class MainViewModel @Inject constructor(
    preferencesRepository: AppPreferencesRepository,
    deviceCapabilities: DeviceCapabilities,
) : ViewModel() {

    val uiState: StateFlow<MainUiState> = combine(
        preferencesRepository.preferences,
        deviceCapabilities.hints,
    ) { preferences, hints ->
        MainUiState.Ready(
            themeMode = preferences.themeMode,
            effects = resolveEffects(preferences.effectsMode, hints),
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000),
        initialValue = MainUiState.Loading,
    )
}
