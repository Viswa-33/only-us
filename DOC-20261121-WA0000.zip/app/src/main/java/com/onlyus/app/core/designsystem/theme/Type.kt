package com.onlyus.app.core.designsystem.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.sp
import com.onlyus.app.R

/**
 * Three bundled fonts, all SIL Open Font License (licences are in assets/licenses). Nothing is downloaded at runtime.
 *
 *  - Playfair Display: major headings, romantic quotes, welcome messages and editorial titles.
 *  - Poppins: body copy, buttons, navigation, labels, descriptions and the rest of the UI.
 *  - Great Vibes: a handwritten accent, used sparingly. Never for long paragraphs, buttons or essential information.
 */
object OnlyUsFonts {
    /** Playfair Display is a variable font. Compose derives the weight axis from the FontWeight given to Font(). */
    val Display = FontFamily(
        Font(R.font.playfair_display, FontWeight.Normal, FontStyle.Normal),
        Font(R.font.playfair_display, FontWeight.Medium, FontStyle.Normal),
        Font(R.font.playfair_display, FontWeight.SemiBold, FontStyle.Normal),
        Font(R.font.playfair_display, FontWeight.Bold, FontStyle.Normal),
        Font(R.font.playfair_display_italic, FontWeight.Normal, FontStyle.Italic),
        Font(R.font.playfair_display_italic, FontWeight.Medium, FontStyle.Italic),
        Font(R.font.playfair_display_italic, FontWeight.SemiBold, FontStyle.Italic),
        Font(R.font.playfair_display_italic, FontWeight.Bold, FontStyle.Italic),
    )

    val Body = FontFamily(
        Font(R.font.poppins_regular, FontWeight.Normal),
        Font(R.font.poppins_medium, FontWeight.Medium),
        Font(R.font.poppins_semibold, FontWeight.SemiBold),
    )

    val Script = FontFamily(
        Font(R.font.great_vibes, FontWeight.Normal),
    )
}

/**
 * Poppins and Great Vibes both carry generous built-in line gaps. Centring the glyphs inside the line box and not
 * trimming it keeps text optically centred in buttons, chips and fields, whatever the font scale.
 */
private val CenteredLines = LineHeightStyle(
    alignment = LineHeightStyle.Alignment.Center,
    trim = LineHeightStyle.Trim.None,
)

private fun display(size: Int, line: Int, spacing: Double = 0.0, weight: FontWeight = FontWeight.Medium) = TextStyle(
    fontFamily = OnlyUsFonts.Display,
    fontWeight = weight,
    fontSize = size.sp,
    lineHeight = line.sp,
    letterSpacing = spacing.sp,
    lineHeightStyle = CenteredLines,
)

private fun body(size: Int, line: Int, spacing: Double, weight: FontWeight) = TextStyle(
    fontFamily = OnlyUsFonts.Body,
    fontWeight = weight,
    fontSize = size.sp,
    lineHeight = line.sp,
    letterSpacing = spacing.sp,
    lineHeightStyle = CenteredLines,
)

/**
 * The Material 3 type scale, mapped to the Only Us fonts.
 * Display, Headline and Title Large are Playfair Display. Title Medium and below are Poppins.
 * Every size, weight, line height and letter spacing in the app comes from this table, never from a Composable.
 * The one deliberate exception is the avatar, whose initials scale with the size of the avatar.
 */
internal val OnlyUsTypography = Typography(
    displayLarge = display(size = 48, line = 58, spacing = -0.5),
    displayMedium = display(size = 40, line = 48, spacing = -0.25),
    displaySmall = display(size = 34, line = 42),
    headlineLarge = display(size = 32, line = 40),
    headlineMedium = display(size = 28, line = 36),
    headlineSmall = display(size = 24, line = 32),
    titleLarge = display(size = 22, line = 30, weight = FontWeight.SemiBold),
    titleMedium = body(size = 16, line = 24, spacing = 0.1, weight = FontWeight.SemiBold),
    titleSmall = body(size = 14, line = 20, spacing = 0.1, weight = FontWeight.SemiBold),
    bodyLarge = body(size = 16, line = 26, spacing = 0.15, weight = FontWeight.Normal),
    bodyMedium = body(size = 14, line = 22, spacing = 0.1, weight = FontWeight.Normal),
    bodySmall = body(size = 12, line = 18, spacing = 0.2, weight = FontWeight.Normal),
    labelLarge = body(size = 15, line = 20, spacing = 0.3, weight = FontWeight.Medium),
    labelMedium = body(size = 12, line = 16, spacing = 0.4, weight = FontWeight.Medium),
    labelSmall = body(size = 11, line = 16, spacing = 0.5, weight = FontWeight.Medium),
)

/**
 * Styles that have no Material 3 slot.
 *
 * RomanticQuote: Playfair Display Italic, for quotes, love-letter lines and welcome messages.
 * HandwrittenAccent: Great Vibes, a short flourish such as a signature or a tagline. Keep it to a few words.
 * HeadlineItalic: Playfair Display Italic for a selected heading, next to the upright headline styles.
 */
object OnlyUsTextStyles {
    val RomanticQuote = TextStyle(
        fontFamily = OnlyUsFonts.Display,
        fontStyle = FontStyle.Italic,
        fontWeight = FontWeight.Normal,
        fontSize = 22.sp,
        lineHeight = 33.sp,
        letterSpacing = 0.1.sp,
        lineHeightStyle = CenteredLines,
    )

    val HandwrittenAccent = TextStyle(
        fontFamily = OnlyUsFonts.Script,
        fontWeight = FontWeight.Normal,
        fontSize = 32.sp,
        lineHeight = 42.sp,
        letterSpacing = 0.sp,
        lineHeightStyle = CenteredLines,
    )

    val HeadlineItalic = TextStyle(
        fontFamily = OnlyUsFonts.Display,
        fontStyle = FontStyle.Italic,
        fontWeight = FontWeight.Medium,
        fontSize = 28.sp,
        lineHeight = 36.sp,
        letterSpacing = 0.sp,
        lineHeightStyle = CenteredLines,
    )

    /** Small caps-style eyebrow above a title. Callers pass the text already in upper case. */
    val Overline = TextStyle(
        fontFamily = OnlyUsFonts.Body,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 1.6.sp,
        lineHeightStyle = CenteredLines,
    )

    /** The logo wordmark. The logo draws it at a fixed size so it never reflows with the system font scale. */
    val Wordmark = TextStyle(
        fontFamily = OnlyUsFonts.Display,
        fontStyle = FontStyle.Italic,
        fontWeight = FontWeight.Medium,
        fontSize = 56.sp,
        lineHeight = 64.sp,
        letterSpacing = (-0.5).sp,
        lineHeightStyle = CenteredLines,
    )

    /** The splash tagline, "Two hearts. One little world." A handwritten accent, deliberately small. */
    val Tagline = HandwrittenAccent.copy(fontSize = 30.sp, lineHeight = 40.sp)
}
