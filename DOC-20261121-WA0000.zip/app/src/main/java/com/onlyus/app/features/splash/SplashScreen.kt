package com.onlyus.app.features.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.components.OnlyUsEmblem
import com.onlyus.app.core.designsystem.components.OnlyUsWordmark
import com.onlyus.app.core.designsystem.components.OrnamentDivider
import com.onlyus.app.core.designsystem.components.drawHeart
import com.onlyus.app.core.designsystem.theme.OnlyUsTextStyles
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme
import kotlinx.coroutines.delay

/**
 * The splash: the emblem fades in while its two hearts drift together, the wordmark rises, a small ornament appears,
 * and the tagline arrives one line at a time. A few faint hearts float up behind it.
 *
 * It is ONE finite animation (a single progress value from 0 to 1). All movement is read while drawing, so the screen
 * never recomposes per frame. With effects reduced it is shorter and drops the floating hearts and glows; with system
 * animations off it shows the finished screen, still, for a moment. It leaves only once the animation has finished AND
 * the saved settings have said where to go next.
 */
@Composable
fun SplashScreen(
    onFinished: (destination: String) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: SplashViewModel = hiltViewModel(),
) {
    val destination by viewModel.destination.collectAsStateWithLifecycle()
    val currentOnFinished by rememberUpdatedState(onFinished)
    val effects = OnlyUsTheme.effects
    val brand = OnlyUsTheme.brand
    val spacing = OnlyUsTheme.spacing
    val description = stringResource(R.string.splash_content_description)

    val progress = remember { Animatable(0f) }
    val readProgress: () -> Float = remember(progress) { { progress.value } }
    var animationDone by remember { mutableStateOf(false) }

    LaunchedEffect(effects.reducedEffects, effects.reducedMotion) {
        animationDone = false
        if (effects.reducedMotion) {
            progress.snapTo(1f)
            delay(SplashTimeline.StaticHoldMillis)
        } else {
            val duration = if (effects.reducedEffects) {
                SplashTimeline.ReducedDurationMillis
            } else {
                SplashTimeline.FullDurationMillis
            }
            progress.snapTo(0f)
            progress.animateTo(targetValue = 1f, animationSpec = tween(durationMillis = duration, easing = LinearEasing))
        }
        animationDone = true
    }

    LaunchedEffect(animationDone, destination) {
        val target = destination
        if (animationDone && target != null) currentOnFinished(target)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            // The splash paints its own, slightly richer gradient. It fades out with the screen transition.
            .background(brand.splashBrush)
            // One spoken description for the whole screen; the decorative pieces are not announced one by one.
            .clearAndSetSemantics { contentDescription = description },
    ) {
        if (!effects.reducedEffects) {
            FloatingHeartsLayer(progress = readProgress)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = spacing.screenHorizontal),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            OnlyUsEmblem(
                size = 168.dp,
                together = { easeOutCubic(segment(readProgress(), SplashTimeline.Hearts)) },
                modifier = Modifier.graphicsLayer {
                    val t = easeOutCubic(segment(readProgress(), SplashTimeline.Emblem))
                    val scale = lerp(0.86f, 1f, t)
                    alpha = t
                    scaleX = scale
                    scaleY = scale
                },
            )

            Spacer(Modifier.height(spacing.md))

            OnlyUsWordmark(
                modifier = Modifier.graphicsLayer {
                    val t = easeOutCubic(segment(readProgress(), SplashTimeline.Wordmark))
                    alpha = t
                    translationY = (1f - t) * 14.dp.toPx()
                },
            )

            Spacer(Modifier.height(spacing.lg))

            OrnamentDivider(
                modifier = Modifier
                    .width(200.dp)
                    .graphicsLayer { alpha = segment(readProgress(), SplashTimeline.Ornament) },
            )

            Spacer(Modifier.height(spacing.md))

            TaglineLine(
                text = stringResource(R.string.app_tagline_first),
                window = SplashTimeline.TaglineFirst,
                progress = readProgress,
            )
            TaglineLine(
                text = stringResource(R.string.app_tagline_second),
                window = SplashTimeline.TaglineSecond,
                progress = readProgress,
            )
        }
    }
}

/** One line of the handwritten tagline, fading up into place during its own slice of the timeline. */
@Composable
private fun TaglineLine(
    text: String,
    window: Window,
    progress: () -> Float,
    modifier: Modifier = Modifier,
) {
    Text(
        text = text,
        style = OnlyUsTextStyles.Tagline,
        color = MaterialTheme.colorScheme.primary,
        textAlign = TextAlign.Center,
        modifier = modifier.graphicsLayer {
            val t = easeOutCubic(segment(progress(), window))
            alpha = t
            translationY = (1f - t) * 10.dp.toPx()
        },
    )
}

/** The faint hearts drifting up behind the logo. One Canvas, drawn from the progress value, never recomposed. */
@Composable
private fun FloatingHeartsLayer(
    progress: () -> Float,
    modifier: Modifier = Modifier,
) {
    val colors = OnlyUsTheme.brand.floatingHearts
    Canvas(modifier = modifier.fillMaxSize()) {
        val overall = progress()
        for (heart in SplashHearts) {
            val frame = heart.frameAt(overall)
            if (frame.alpha <= 0.01f) continue
            drawHeart(
                color = colors[heart.colorIndex % colors.size],
                center = Offset(frame.x * size.width, frame.y * size.height),
                size = heart.sizeDp.dp.toPx(),
                rotationDegrees = frame.rotation,
                alpha = frame.alpha,
            )
        }
    }
}
