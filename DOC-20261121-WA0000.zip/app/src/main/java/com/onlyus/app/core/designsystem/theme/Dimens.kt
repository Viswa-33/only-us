package com.onlyus.app.core.designsystem.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** 4-point spacing scale. Read it with OnlyUsTheme.spacing. */
@Immutable
data class Spacing(
    val xxs: Dp = 2.dp,
    val xs: Dp = 4.dp,
    val sm: Dp = 8.dp,
    val md: Dp = 12.dp,
    val lg: Dp = 16.dp,
    val xl: Dp = 24.dp,
    val xxl: Dp = 32.dp,
    val xxxl: Dp = 48.dp,
    val screenHorizontal: Dp = 20.dp,
    val minTouchTarget: Dp = 48.dp,
)

/** Corner radius scale. Pills use [OnlyUsShapes.Pill]. */
object OnlyUsRadius {
    val xs = 8.dp
    val sm = 12.dp
    val md = 16.dp
    val lg = 24.dp
    val xl = 32.dp
}

object OnlyUsShapes {
    /** Fully rounded ends: buttons, chips, the navigation bar. */
    val Pill = CircleShape
}

internal val OnlyUsMaterialShapes = Shapes(
    extraSmall = RoundedCornerShape(OnlyUsRadius.xs),
    small = RoundedCornerShape(OnlyUsRadius.sm),
    medium = RoundedCornerShape(OnlyUsRadius.md),
    large = RoundedCornerShape(OnlyUsRadius.lg),
    extraLarge = RoundedCornerShape(OnlyUsRadius.xl),
)

/** Animation timings shared across the app. All animations are finite. */
object OnlyUsMotion {
    const val Short = 200
    const val Medium = 400
    const val Long = 600
}
