package com.onlyus.app.core.designsystem.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.theme.OnlyUsTextStyles
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

/**
 * A round avatar with a rose-gold ring. Shows [initials] in Playfair Display, or a small heart when there are none.
 * [online] adds a status dot (green when true, grey when false); leave it null for no dot. The dot is decorative:
 * say the status in text next to the avatar, as ProfileCard does.
 */
@Composable
fun OnlyUsAvatar(
    initials: String?,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    ring: Boolean = true,
    online: Boolean? = null,
) {
    val scheme = MaterialTheme.colorScheme
    val brand = OnlyUsTheme.brand
    val fill = Brush.linearGradient(listOf(scheme.primaryContainer, scheme.secondaryContainer))

    Box(modifier = modifier.size(size)) {
        Box(
            modifier = Modifier
                .size(size)
                .then(if (ring) Modifier.border(2.dp, brand.ringBrush, CircleShape) else Modifier)
                .background(fill, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (initials.isNullOrBlank()) {
                HeartIcon(size = size * 0.38f, brush = brand.heartBurgundyBrush)
            } else {
                Text(
                    text = initials,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontSize = (size.value * 0.34f).sp,
                        lineHeight = (size.value * 0.44f).sp,
                    ),
                    color = scheme.onPrimaryContainer,
                    maxLines = 1,
                )
            }
        }
        if (online != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(size * 0.26f)
                    .background(if (online) brand.success else scheme.outline, CircleShape)
                    .border(2.dp, scheme.surface, CircleShape),
            )
        }
    }
}

/** An avatar, a name and a status line on a glass card, with an optional action at the end. */
@Composable
fun ProfileCard(
    name: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    initials: String? = initialsOf(name),
    online: Boolean? = null,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    val scheme = MaterialTheme.colorScheme
    GlassCard(modifier = modifier, onClick = onClick) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.lg),
        ) {
            OnlyUsAvatar(initials = initials, online = online)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.titleMedium,
                    color = scheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            trailing?.invoke()
        }
    }
}

/** Two overlapping avatars with a heart between them, both names, and a handwritten caption. */
@Composable
fun CoupleCard(
    firstName: String,
    secondName: String,
    caption: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    val scheme = MaterialTheme.colorScheme
    val brand = OnlyUsTheme.brand
    val spacing = OnlyUsTheme.spacing
    val avatar = 76.dp

    PremiumCard(modifier = modifier, onClick = onClick) {
        Column(
            modifier = Modifier.align(Alignment.CenterHorizontally),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(modifier = Modifier.width(avatar + 60.dp), contentAlignment = Alignment.Center) {
                OnlyUsAvatar(initials = initialsOf(firstName), size = avatar, modifier = Modifier.offset(x = (-30).dp))
                OnlyUsAvatar(initials = initialsOf(secondName), size = avatar, modifier = Modifier.offset(x = 30.dp))
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .background(scheme.surface, CircleShape)
                        .border(1.dp, scheme.outlineVariant, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    HeartIcon(size = 16.dp, brush = brand.heartBurgundyBrush)
                }
            }
            Spacer(Modifier.height(spacing.lg))
            Text(
                text = stringResource(R.string.couple_names, firstName, secondName),
                style = MaterialTheme.typography.headlineSmall,
                color = scheme.onSurface,
                textAlign = TextAlign.Center,
            )
            Text(
                text = caption,
                style = OnlyUsTextStyles.Tagline,
                color = scheme.secondary,
                textAlign = TextAlign.Center,
            )
        }
    }
}
