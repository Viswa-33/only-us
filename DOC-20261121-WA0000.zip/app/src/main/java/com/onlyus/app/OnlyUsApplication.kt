package com.onlyus.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * The application class exists only to start Hilt. Nothing else belongs here:
 * work done at process start delays every launch of the app.
 */
@HiltAndroidApp
class OnlyUsApplication : Application()
