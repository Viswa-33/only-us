package com.onlyus.app.features.showcase

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.onlyus.app.core.designsystem.theme.EffectsMode
import com.onlyus.app.core.preferences.AppPreferencesRepository
import com.onlyus.app.core.preferences.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** The two appearance choices the gallery lets you change. Both are saved on the device. */
data class AppearanceState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val effectsMode: EffectsMode = EffectsMode.AUTO,
)

@HiltViewModel
class ShowcaseViewModel @Inject constructor(
    private val preferencesRepository: AppPreferencesRepository,
) : ViewModel() {

    val appearance: StateFlow<AppearanceState> = preferencesRepository.preferences
        .map { AppearanceState(themeMode = it.themeMode, effectsMode = it.effectsMode) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000),
            initialValue = AppearanceState(),
        )

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferencesRepository.setThemeMode(mode) }
    }

    fun setEffectsMode(mode: EffectsMode) {
        viewModelScope.launch { preferencesRepository.setEffectsMode(mode) }
    }
}
