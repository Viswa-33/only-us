package com.onlyus.app.core.designsystem.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.onlyus.app.core.designsystem.theme.BrandColors
import com.onlyus.app.core.designsystem.theme.OnlyUsShapes
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

// Material 3 disabled states: faint container, 38% content.
private const val DisabledContainerAlpha = 0.12f
private const val DisabledContentAlpha = 0.38f

enum class GlassButtonStyle {
    /** The one main action on a screen: a burgundy gradient (a soft rose in dark mode) with a gentle glow. */
    Primary,

    /** A supporting action: a glass pill with a rose-gold edge. */
    Secondary,

    /** The quietest action: text only. */
    Text,
}

/**
 * The Only Us button. On press it scales down a touch and shows a ripple. [loading] swaps the label for the heart
 * loader without changing the button's width, and blocks taps while it runs. Touch height is always at least 48dp.
 */
@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: GlassButtonStyle = GlassButtonStyle.Primary,
    enabled: Boolean = true,
    loading: Boolean = false,
    @DrawableRes leadingIcon: Int? = null,
    @DrawableRes trailingIcon: Int? = null,
) {
    val scheme = MaterialTheme.colorScheme
    val brand = OnlyUsTheme.brand
    val glass = OnlyUsTheme.glass
    val effects = OnlyUsTheme.effects
    val spacing = OnlyUsTheme.spacing
    val shape = OnlyUsShapes.Pill
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val tappable = enabled && !loading

    val scale = animateFloatAsState(
        targetValue = if (pressed && tappable && !effects.reducedMotion) 0.97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "buttonScale",
    )

    val contentColor = when {
        !enabled -> scheme.onSurface.copy(alpha = DisabledContentAlpha)
        style == GlassButtonStyle.Primary -> brand.onAction
        else -> scheme.primary
    }
    val surface: Modifier = when {
        style == GlassButtonStyle.Text -> Modifier
        !enabled -> Modifier.background(scheme.onSurface.copy(alpha = DisabledContainerAlpha), shape)
        style == GlassButtonStyle.Primary -> Modifier.primarySurface(shape, brand, effects.reducedEffects)
        else -> Modifier.glassSurface(
            shape = shape,
            glass = glass,
            effects = effects,
            strength = GlassStrength.Strong,
            elevation = GlassDefaults.ControlElevation,
            borderWidth = 1.5.dp,
            borderBrush = SolidColor(brand.roseGold),
        )
    }

    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 64.dp, minHeight = if (style == GlassButtonStyle.Text) 48.dp else 52.dp)
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            }
            .then(surface)
            .clip(shape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = if (style == GlassButtonStyle.Primary) brand.onAction else scheme.primary),
                enabled = tappable,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = spacing.xl, vertical = spacing.md),
        contentAlignment = Alignment.Center,
    ) {
        // The label stays in the layout while loading, only invisible, so the button never changes width.
        Row(
            modifier = Modifier.graphicsLayer { alpha = if (loading) 0f else 1f },
            horizontalArrangement = Arrangement.spacedBy(spacing.sm),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (leadingIcon != null) {
                Icon(painterResource(leadingIcon), contentDescription = null, modifier = Modifier.size(18.dp), tint = contentColor)
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                color = contentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (trailingIcon != null) {
                Icon(painterResource(trailingIcon), contentDescription = null, modifier = Modifier.size(18.dp), tint = contentColor)
            }
        }
        if (loading) {
            OnlyUsLoadingIndicator(size = 24.dp, color = contentColor)
        }
    }
}

private fun Modifier.primarySurface(shape: Shape, brand: BrandColors, reducedEffects: Boolean): Modifier {
    val glow = brand.actionStart.copy(alpha = 0.40f)
    return this
        .then(
            if (reducedEffects) {
                Modifier
            } else {
                Modifier.shadow(8.dp, shape, clip = false, ambientColor = glow, spotColor = glow)
            },
        )
        .background(brand.actionBrush, shape)
        .then(if (reducedEffects) Modifier else Modifier.background(brand.actionSheen, shape))
        .border(1.dp, brand.actionBorder, shape)
}

enum class IconButtonStyle {
    /** Just the icon. */
    Plain,

    /** The icon on a soft blush circle. */
    Tonal,

    /** The icon on a glass circle. */
    Glass,
}

/**
 * A round icon button. The tap target is always 48dp; the visible circle is 40dp.
 * [contentDescription] is required, because an icon alone says nothing to a screen reader.
 * Pass [badge] to overlay something on the corner, usually a [NotificationBadge] aligned to the top end.
 */
@Composable
fun OnlyUsIconButton(
    @DrawableRes icon: Int,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: IconButtonStyle = IconButtonStyle.Plain,
    enabled: Boolean = true,
    tint: Color = Color.Unspecified,
    badge: (@Composable BoxScope.() -> Unit)? = null,
) {
    val scheme = MaterialTheme.colorScheme
    val glass = OnlyUsTheme.glass
    val effects = OnlyUsTheme.effects
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale = animateFloatAsState(
        targetValue = if (pressed && enabled && !effects.reducedMotion) 0.90f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "iconButtonScale",
    )

    val resolvedTint = when {
        !enabled -> scheme.onSurface.copy(alpha = DisabledContentAlpha)
        tint != Color.Unspecified -> tint
        style == IconButtonStyle.Tonal -> scheme.onPrimaryContainer
        else -> scheme.onSurface
    }
    val visual: Modifier = when (style) {
        IconButtonStyle.Plain -> Modifier
        IconButtonStyle.Tonal -> Modifier.background(
            if (enabled) scheme.primaryContainer else scheme.onSurface.copy(alpha = DisabledContainerAlpha),
            CircleShape,
        )
        IconButtonStyle.Glass -> Modifier.glassSurface(
            shape = CircleShape,
            glass = glass,
            effects = effects,
            strength = GlassStrength.Strong,
            elevation = GlassDefaults.ControlElevation,
        )
    }

    Box(
        modifier = modifier
            .size(48.dp)
            .then(if (badge != null) Modifier.semantics(mergeDescendants = true) {} else Modifier),
    ) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                }
                .clickable(
                    interactionSource = interactionSource,
                    indication = ripple(bounded = false, radius = 24.dp),
                    enabled = enabled,
                    role = Role.Button,
                    onClick = onClick,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Box(modifier = Modifier.size(40.dp).then(visual), contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(icon),
                    contentDescription = contentDescription,
                    modifier = Modifier.size(24.dp),
                    tint = resolvedTint,
                )
            }
        }
        badge?.invoke(this)
    }
}
