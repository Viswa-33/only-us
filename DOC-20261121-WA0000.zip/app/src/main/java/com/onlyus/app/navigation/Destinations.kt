package com.onlyus.app.navigation

/** Route names for every screen. One place, so a typo cannot create a dead route. */
object Destinations {
    const val Splash = "splash"
    const val Onboarding = "onboarding"

    /** The design-system gallery. Home replaces it as the first real screen in the next phase. */
    const val Showcase = "showcase"
}
