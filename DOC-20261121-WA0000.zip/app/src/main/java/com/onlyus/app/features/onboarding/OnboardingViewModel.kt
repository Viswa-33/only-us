package com.onlyus.app.features.onboarding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.onlyus.app.core.preferences.AppPreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val preferencesRepository: AppPreferencesRepository,
) : ViewModel() {

    private var completing = false

    /**
     * Remembers that onboarding has been seen, and only then calls [onDone] (which leaves the screen).
     * Saving first matters: leaving the screen clears this ViewModel, which would cancel a save still in flight.
     * A second tap while the first is being saved is ignored.
     */
    fun complete(onDone: () -> Unit) {
        if (completing) return
        completing = true
        viewModelScope.launch {
            preferencesRepository.setOnboardingCompleted(true)
            onDone()
        }
    }
}
