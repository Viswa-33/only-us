package com.onlyus.app.core.designsystem.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme

/**
 * The Only Us heart, defined once in unit space (0..1). The launcher icon is generated from the same curves,
 * so the logo, the loader, the splash and the ornaments all share one shape. Built from cubic curves, never an emoji,
 * so it looks identical on every device.
 */
internal val UnitHeartPath: Path = Path().apply {
    moveTo(0.50f, 0.93f)
    cubicTo(0.20f, 0.70f, 0.03f, 0.52f, 0.03f, 0.30f)
    cubicTo(0.03f, 0.14f, 0.15f, 0.04f, 0.29f, 0.04f)
    cubicTo(0.39f, 0.04f, 0.47f, 0.09f, 0.50f, 0.18f)
    cubicTo(0.53f, 0.09f, 0.61f, 0.04f, 0.71f, 0.04f)
    cubicTo(0.85f, 0.04f, 0.97f, 0.14f, 0.97f, 0.30f)
    cubicTo(0.97f, 0.52f, 0.80f, 0.70f, 0.50f, 0.93f)
    close()
}

/**
 * Draws the heart centred on [center], [size] pixels wide, turned by [rotationDegrees].
 * Gradient brushes must be written in unit space (0..1): the path is scaled up by a canvas transform.
 */
internal fun DrawScope.drawHeart(
    brush: Brush,
    center: Offset,
    size: Float,
    rotationDegrees: Float = 0f,
    alpha: Float = 1f,
) {
    withTransform({
        translate(left = center.x - size / 2f, top = center.y - size / 2f)
        rotate(degrees = rotationDegrees, pivot = Offset(size / 2f, size / 2f))
        scale(scaleX = size, scaleY = size, pivot = Offset.Zero)
    }) {
        drawPath(path = UnitHeartPath, brush = brush, alpha = alpha)
    }
}

/** A flat-colour heart, for dividers, bullets and anywhere a gradient would be too much. */
internal fun DrawScope.drawHeart(
    color: Color,
    center: Offset,
    size: Float,
    rotationDegrees: Float = 0f,
    alpha: Float = 1f,
) {
    withTransform({
        translate(left = center.x - size / 2f, top = center.y - size / 2f)
        rotate(degrees = rotationDegrees, pivot = Offset(size / 2f, size / 2f))
        scale(scaleX = size, scaleY = size, pivot = Offset.Zero)
    }) {
        drawPath(path = UnitHeartPath, color = color, alpha = alpha)
    }
}

/** An outlined heart. [strokeWidthPx] is in real pixels, not unit space. */
internal fun DrawScope.drawHeartOutline(
    color: Color,
    center: Offset,
    size: Float,
    strokeWidthPx: Float,
    rotationDegrees: Float = 0f,
    alpha: Float = 1f,
) {
    withTransform({
        translate(left = center.x - size / 2f, top = center.y - size / 2f)
        rotate(degrees = rotationDegrees, pivot = Offset(size / 2f, size / 2f))
        scale(scaleX = size, scaleY = size, pivot = Offset.Zero)
    }) {
        drawPath(path = UnitHeartPath, color = color, alpha = alpha, style = Stroke(width = strokeWidthPx / size))
    }
}

/** A small decorative heart. It is hidden from accessibility services. */
@Composable
fun HeartIcon(
    modifier: Modifier = Modifier,
    size: Dp = 16.dp,
    brush: Brush = OnlyUsTheme.brand.heartRoseGoldBrush,
) {
    Canvas(modifier.size(size)) {
        drawHeart(brush = brush, center = center, size = this.size.minDimension)
    }
}
