package com.onlyus.app.features.showcase

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.onlyus.app.R
import com.onlyus.app.core.designsystem.components.GlassNavigationBar
import com.onlyus.app.core.designsystem.components.NavBarItem
import com.onlyus.app.core.designsystem.components.OnlyUsTopBar
import com.onlyus.app.core.designsystem.components.SectionHeader
import com.onlyus.app.core.designsystem.theme.EffectsMode
import com.onlyus.app.core.designsystem.theme.OnlyUsTheme
import com.onlyus.app.core.preferences.ThemeMode

/**
 * The design-system gallery: every token and component, live, in the current theme.
 * It is the first screen after onboarding until the real Home screen exists, and a handy place to check light and
 * dark mode, reduced effects and font sizes in one scroll.
 */
@Composable
fun ShowcaseScreen(
    modifier: Modifier = Modifier,
    viewModel: ShowcaseViewModel = hiltViewModel(),
) {
    val appearance by viewModel.appearance.collectAsStateWithLifecycle()
    ShowcaseContent(
        appearance = appearance,
        onThemeModeChange = viewModel::setThemeMode,
        onEffectsModeChange = viewModel::setEffectsMode,
        modifier = modifier,
    )
}

@Composable
internal fun ShowcaseContent(
    appearance: AppearanceState,
    onThemeModeChange: (ThemeMode) -> Unit,
    onEffectsModeChange: (EffectsMode) -> Unit,
    modifier: Modifier = Modifier,
) {
    val spacing = OnlyUsTheme.spacing
    val listState = rememberLazyListState()
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    // The top bar gains a calm surface and a hairline once the list has moved.
    val scrolled by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4 }
    }

    // The navigation bar steps aside while the keyboard is open, so a focused field is never squeezed between them.
    val density = LocalDensity.current
    val ime = WindowInsets.ime
    val keyboardVisible by remember { derivedStateOf { ime.getBottom(density) > 0 } }

    val navItems = listOf(
        NavBarItem(label = stringResource(R.string.nav_home), icon = R.drawable.ic_nav_home),
        NavBarItem(label = stringResource(R.string.nav_chat), icon = R.drawable.ic_nav_chat, badgeCount = 3),
        NavBarItem(label = stringResource(R.string.nav_memories), icon = R.drawable.ic_nav_memories),
        NavBarItem(label = stringResource(R.string.nav_forever), icon = R.drawable.ic_nav_forever),
        NavBarItem(label = stringResource(R.string.nav_us), icon = R.drawable.ic_nav_profile),
    )

    Column(modifier = modifier.fillMaxSize()) {
        OnlyUsTopBar(
            title = stringResource(R.string.showcase_title),
            scrolled = scrolled,
        )

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .imePadding(),
            contentPadding = PaddingValues(horizontal = spacing.screenHorizontal, vertical = spacing.lg),
            verticalArrangement = Arrangement.spacedBy(spacing.xxl),
        ) {
            item(key = "intro") { IntroSection() }
            item(key = "appearance") {
                AppearanceSection(
                    appearance = appearance,
                    onThemeModeChange = onThemeModeChange,
                    onEffectsModeChange = onEffectsModeChange,
                )
            }
            item(key = "typography") { TypographySection() }
            item(key = "palette") { PaletteSection() }
            item(key = "buttons") { ButtonsSection() }
            item(key = "iconButtons") { IconButtonsSection() }
            item(key = "cards") { CardsSection() }
            item(key = "profiles") { ProfilesSection() }
            item(key = "fields") { FieldsSection() }
            item(key = "feedback") { FeedbackSection() }
            item(key = "dividers") { DividersSection() }
            item(key = "emptyState") { EmptyStateSection() }
        }

        // Docked below the list rather than floating over it: glass is translucent, so it looks best over the plain
        // background and never sits on top of scrolling text.
        if (!keyboardVisible) {
            GlassNavigationBar(
                items = navItems,
                selectedIndex = selectedTab,
                onSelect = { selectedTab = it },
            )
        }
    }
}

/** A titled group in the gallery: a section header, then its content, evenly spaced. */
@Composable
internal fun ShowcaseSection(
    title: String,
    modifier: Modifier = Modifier,
    overline: String? = null,
    hint: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(OnlyUsTheme.spacing.lg),
    ) {
        SectionHeader(title = title, overline = overline, subtitle = hint)
        content()
    }
}
