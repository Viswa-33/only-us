package com.onlyus.app.features.splash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.onlyus.app.core.preferences.AppPreferences
import com.onlyus.app.core.preferences.AppPreferencesRepository
import com.onlyus.app.navigation.Destinations
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class SplashViewModel @Inject constructor(
    preferencesRepository: AppPreferencesRepository,
) : ViewModel() {

    /**
     * Where to go once the splash has played: onboarding on the very first launch, the gallery afterwards.
     * Null until the saved settings have been read, so the screen never guesses.
     */
    val destination: StateFlow<String?> = preferencesRepository.preferences
        .map<AppPreferences, String?> { preferences ->
            if (preferences.onboardingCompleted) Destinations.Showcase else Destinations.Onboarding
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000),
            initialValue = null,
        )
}
