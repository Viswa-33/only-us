# R8 / ProGuard rules for release builds.
# Hilt, Compose, Navigation, DataStore and AndroidX ship their own consumer rules, so Phase 1 needs no keep rules.
# Add rules here only when a release build proves that something is missing (Phase 10 covers release testing).

# Keep readable stack traces for crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
