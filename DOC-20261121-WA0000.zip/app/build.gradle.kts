// No org.jetbrains.kotlin.android here: AGP 9 compiles Kotlin natively ("built-in Kotlin").
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

android {
    namespace = "com.onlyus.app"
    compileSdk = 37 // Compose 1.12 requires compileSdk 37; this does not change which phones can run the app.

    defaultConfig {
        // Change applicationId now if you want a different one: Firebase (Phase 3) is registered against it.
        applicationId = "com.onlyus.app"
        minSdk = 31 // Android 12
        targetSdk = 35 // Android 15. Raise to the current Google Play requirement before a Play Store release (Phase 10).
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    // With built-in Kotlin the Kotlin jvmTarget follows compileOptions, so it is set only here.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Compose (versions are controlled by the BOM)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui.tooling.preview)
    debugImplementation(libs.androidx.compose.ui.tooling)

    // AndroidX
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.datastore.preferences)

    // Coroutines and Flow
    implementation(libs.kotlinx.coroutines.android)

    // Hilt (KSP, not kapt)
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.androidx.hilt.lifecycle.viewmodel.compose)

    // Unit tests (plain JVM)
    testImplementation(libs.junit)
}
