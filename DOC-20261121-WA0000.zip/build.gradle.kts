// Top-level build file. Plugins are declared here (versions come from gradle/libs.versions.toml)
// and applied in the modules that need them.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.compose.compiler) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false

    // AGP 9 compiles Kotlin itself ("built-in Kotlin"), so no module applies org.jetbrains.kotlin.android.
    // This entry is never applied. It only puts the Kotlin Gradle Plugin version below on the build
    // classpath, so that Kotlin and the Compose compiler plugin are guaranteed to be the same version.
    alias(libs.plugins.kotlin.version.pin) apply false
}
