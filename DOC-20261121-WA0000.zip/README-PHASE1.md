# ONLY US ❤️ — Phase 1 · Stage 4

### The project foundation and the Liquid Glass design system

*Two hearts. One little world.*

---

## 1. Read this first

**What this is.** A complete native Android project (Kotlin, Jetpack Compose, Material 3, MVVM, Hilt, Navigation
Compose, DataStore) containing the whole design system, the animated splash, a three-page onboarding, and a live
in-app gallery that shows every component in light and dark.

**What is verified, and what is not.**
I could check a lot without a build (section 8): syntax, resources, imports, colour contrast, and 47 unit tests that
compile and pass. I could **not** run the real Gradle build. The sandbox I work in blocks the servers that host the
Android Gradle Plugin, Compose and Hilt (Maven Central, Google Maven, the Gradle Plugin Portal and
services.gradle.org all return HTTP 403), so nothing that touches Android, Compose or Hilt has been compiled. I will not
call it "built" until you have built it.

**What I need from you.** Build it once, either in Android Studio (section 2) or with the free cloud build (section 2A,
for anyone who does not use Android Studio), and tell me one of two things: "it runs", or the **first** error, pasted
as text. Stage 5 (the Home screen) and Firebase do not start until you say the build works.

---

## 2A. No Android Studio? Let GitHub build the APK

GitHub's free computers can build the app and hand you an installable `.apk`. The recipe is
`.github/workflows/build-apk.yml`. It passes GitHub's workflow-file schema check and its helper scripts were tested
on sample inputs, but it has **not been run on GitHub yet**, and neither has the Gradle build it starts.

1. Make a free GitHub account and a **private** repository (tick "Add a README file").
2. **Add file ▸ Upload files**, and drop in `OnlyUs.zip` as it is (do not unzip it). Commit.
3. **Add file ▸ Create new file**, type the name `.github/workflows/build.yml`, paste the contents of
   `.github/workflows/build-apk.yml`, and commit. This starts the first build.
4. Open the **Actions** tab. When the run turns green, download `OnlyUs-test.apk` from **Artifacts** (or from
   **Releases**) and open it on an Android 12 or newer phone.
5. If the run turns red, open it and copy the grey box on its Summary page to Claude. A fixed zip is then uploaded
   again, which repeats step 2 and starts a new build by itself.

Each build is signed with a fresh debug key, so uninstall the old build before installing a newer one. A fixed signing
key is set up later, when something needs it.

---

## 2. Open it and run it

1. Install the latest stable **Android Studio**. It will tell you if it needs an update for Android Gradle Plugin 9.3.
   JDK 17 or newer is required; the one bundled with Studio is fine.
2. Unzip, then **File ▸ Open** and choose the `OnlyUs` folder.
3. Wait for **Gradle sync** to finish. The first sync downloads Gradle 9.5.0 and every library, so it needs internet
   and a few minutes.
4. Choose a phone or emulator running **Android 12 (API 31) or newer** and press ▶ **Run**.
5. Optional: run the unit tests with `./gradlew testDebugUnitTest`, or right-click `app/src/test` ▸ **Run Tests**.
6. Optional: open `features/showcase/ShowcasePreviews.kt` and switch to **Split** view to see every component in light
   and dark without running the app.

**If sync or the build fails:** copy the first error in the **Build** tab and send it to me. Please do not edit versions
by hand first. If you want to try something yourself, change one line at a time in `gradle/libs.versions.toml`,
starting with `kotlin` (try 2.3.20); the notes at the top of that file say which versions belong together.

---

## 3. What you will see

1. **System splash.** An instant of plain warm ivory (charcoal in dark mode). No icon, so there is no flash.
2. **Animated splash (about 2.8 seconds).** The two-heart emblem draws together, seven small hearts drift up behind it,
   the *Only Us* wordmark arrives, a rose-gold ornament appears, then the tagline in handwriting:
   *Two hearts. One little world.* The whole thing is **one finite animation**, never a loop.
   With Battery Saver, a low-memory phone, or "Reduced effects" it plays a shorter, calmer version (1.1 s, no floating
   hearts). With system animations switched off it shows the finished splash for 0.7 s without motion.
3. **Onboarding.** Three pages: swipe or Continue, Skip, an animated dot indicator, and "Get started" on the last page.
   Finishing is remembered, so the next launch goes straight past it.
4. **Design-system gallery.** Until the real Home screen exists (Phase 2), the app opens a scrolling gallery of
   everything: appearance switches (System / Light / Dark, Auto / Full / Reduced effects, both remembered), the type
   scale, the palette, buttons, icon buttons with an animated badge, cards, profile cards, form fields with live
   validation, loaders, dividers, empty states, and the glass navigation bar docked at the bottom.

I have not seen any of this on a device. This describes what the code does.

---

## 4. The design system at a glance

Everything below lives in `core/designsystem/theme`. Screens and components never write a hex value, and they take
text styles, spacing and corner radii from the tokens. A few literal sizes remain where they are part of one
component's own geometry (a 1 dp hairline, a 40 dp icon circle, an avatar's size).

### Palette

Deep burgundy, blush pink, warm ivory, rose gold and elegant charcoal.

| Role | Light | Dark |
|---|---|---|
| Background | warm ivory `#FBF5EE` | charcoal `#161214` |
| Surface | `#FFFBF7` | `#1E181B` |
| Primary | deep burgundy `#7B1E3A` | muted rose `#E3A5B3` |
| Primary container | blush `#F8DADF` | burgundy `#6A1F39` |
| Secondary (rose gold for text and icons) | `#8E4B57` | champagne rose gold `#E4B9AB` |
| Tertiary | `#A33A57` | blush `#F2B8C6` |
| Text | ink `#2A2327` | `#F4EAEA` |
| Secondary text | `#5E5358` | `#CDBEC3` |
| Outline (field borders) | `#84737A` | `#A7959C` |
| Error | `#B3261E` | `#F2B8B5` |
| Success | `#2F6B4F` | `#9BD3B1` |

The raw swatches (burgundy 950/800/700/600, blush 100/200, ivory 50/100/200, rose gold 300/500/700, charcoal, plum) are
in `Color.kt`. Gradients are used sparingly: the page background, the primary button, the logo wordmark and hairlines.

### Typography

Three fonts, bundled in the app (SIL Open Font License; licences in `assets/licenses`). Nothing is downloaded.

- **Playfair Display** for major headings, romantic quotes, welcome messages and editorial titles.
- **Poppins** for body text, buttons, navigation, labels and the rest of the UI.
- **Great Vibes** for a handwritten accent, kept to a few words.

| Style | Font | Size / line |
|---|---|---|
| Display Large | Playfair Display Medium | 48 / 58 |
| Display Medium | Playfair Display Medium | 40 / 48 |
| Headline Large | Playfair Display Medium | 32 / 40 |
| Headline Medium | Playfair Display Medium | 28 / 36 |
| Title Large | Playfair Display SemiBold | 22 / 30 |
| Title Medium | Poppins SemiBold | 16 / 24 |
| Body Large | Poppins Regular | 16 / 26 |
| Body Medium | Poppins Regular | 14 / 22 |
| Label Large | Poppins Medium | 15 / 20 |
| Romantic Quote | Playfair Display Italic | 22 / 33 |
| Handwritten Accent | Great Vibes | 32 / 42 |

The other Material 3 slots (Display Small, Headline Small, Title Small, Body Small, Label Medium, Label Small) are
filled in too, plus `Overline`, `Wordmark`, `Tagline` and `HeadlineItalic` in `OnlyUsTextStyles`.

### Spacing, corners, motion

- **Spacing** (4-point scale): 2, 4, 8, 12, 16, 24, 32, 48 dp. Screen side padding 20 dp. Minimum touch target 48 dp.
- **Corner radius:** 8, 12, 16, 24, 32 dp, plus a full pill.
- **Motion:** 200 ms (short), 400 ms (medium), 600 ms (long). Every animation is finite, except the loader's
  heartbeat, which runs only while it is actually loading.

### The glass recipe (no blur anywhere)

Glass is **simulated**: a translucent gradient fill, a faint top sheen, a thin luminous border and a tinted soft shadow.
There is no real-time blur, which keeps it cheap on every phone. Brushes are built once per theme, not per frame.

### Effects modes

| Mode | What it does |
|---|---|
| **Auto** (default) | Reduces effects if the phone reports low RAM or Battery Saver is on |
| **Full** | Always full polish |
| **Reduced** | Flat themed surfaces and plain borders. No shadows, sheen, background glows or floating hearts |

Separately, if the system animation scale is 0 the app skips non-essential motion. The rule lives in one tested
function, `resolveEffects`.

### One theme, one place

`OnlyUsTheme(darkTheme, effects)` wraps the app. Components read `MaterialTheme.colorScheme`, `typography` and
`shapes`, plus `OnlyUsTheme.spacing`, `.glass`, `.brand` and `.effects`. Switching light and dark animates the colours
over 600 ms (it snaps when effects or motion are reduced).

---

## 5. Components

All in `core/designsystem/components`. They read their colours, type styles, spacing and corners from the theme.

| Component | What it is |
|---|---|
| `GlassButton` | Primary (burgundy gradient, soft rose in dark), Secondary (glass pill with a rose-gold edge) and Text styles. Gentle press scale and ripple, optional icons, a `loading` state that keeps its width, 48 dp minimum height |
| `OnlyUsIconButton` | Minimalist round icon button: Plain, Tonal or Glass. 48 dp target, 40 dp circle, a `badge` slot. A content description is required |
| `GlassCard` | Translucent glass card; pressable with scale and ripple; animates its size when content changes |
| `PremiumCard` | Solid ivory-paper card with a hairline border and a soft shadow that lowers when pressed, for long text and forms |
| `OnlyUsTextField` | Floating-label field with default, focused, error, success and disabled states, a leading icon, supporting text and a password toggle. Errors are announced by screen readers and never rely on colour alone |
| `GlassChip` | Selectable pill for choices |
| `OnlyUsAvatar`, `ProfileCard`, `CoupleCard` | Round avatar with a rose-gold ring and optional status dot; a profile row; a two-avatar couple card with a handwritten caption |
| `GlassNavigationBar` | Floating glass bar with a pill that springs to the selected tab, labels always visible, badge support |
| `OnlyUsTopBar` | Transparent title bar that gains a calm surface once content scrolls under it |
| `NotificationBadge` | Pops in with a soft spring, hides at zero, the number slides, caps at 99+ |
| `OnlyUsLoadingIndicator` | A beating heart with an echo ring; a still heart when motion is reduced |
| `AnimatedText` | Text that cross-fades when it changes |
| `OnlyUsDivider`, `OrnamentDivider`, `SectionHeader` | Fading rose-gold hairline; hairlines with a small heart; overline + title + description + action |
| `EmptyState` + `LetterIllustration`, `ChatIllustration`, `PhotosIllustration` | Friendly empty screens with drawn illustrations |
| `OnlyUsEmblem`, `OnlyUsWordmark`, `HeartIcon` | The logo pieces and the heart used as an accent |
| `OnlyUsBackground` | The shared page gradient with soft glows (glows omitted when effects are reduced) |
| `Modifier.glassSurface` | The glass recipe as a modifier, for your own surfaces |

### Stage 4 checklist

| You asked for | Where it is |
|---|---|
| Palette: burgundy, blush, ivory, rose gold, charcoal | `Color.kt`, `GlassTokens.kt` |
| Premium rounded cards with subtle shadows | `GlassCard`, `PremiumCard` |
| Elegant gradient buttons, scale + ripple | `GlassButton` |
| Minimalist icon buttons | `OnlyUsIconButton` |
| Profile cards | `ProfileCard`, `CoupleCard`, `OnlyUsAvatar` |
| Modern navigation elements | `GlassNavigationBar`, `OnlyUsTopBar` |
| Animated notification badges | `NotificationBadge` |
| Smooth loading indicators | `OnlyUsLoadingIndicator` |
| Dividers and section headers | `OnlyUsDivider`, `OrnamentDivider`, `SectionHeader` |
| Empty states with illustrations | `EmptyState` and three illustrations |
| Inputs with floating labels and all states | `OnlyUsTextField` |
| Centralised Material 3 theme and tokens | `core/designsystem/theme` |
| Light and dark, smooth theme transition | `Theme.kt`, `ThemeTransition.kt` |
| Heart accents, micro-animations, glass surfaces | `Hearts.kt`, component animations, `GlassSurface.kt` |
| Smooth screen transitions | `navigation/OnlyUsNavHost.kt` (400 ms fade + slight rise; none when motion is reduced) |
| Local fonts, central typography, 11 styles | `Type.kt`, `res/font`, the gallery's Typography section |

---

## 6. Project structure and what each file does

```
OnlyUs/
├── settings.gradle.kts            Repositories (Google, Maven Central) and the :app module
├── build.gradle.kts               Top-level plugin declarations (versions come from the catalog)
├── gradle.properties              Gradle memory, AndroidX on, AGP 9 defaults left alone
├── gradle/libs.versions.toml      Every version in one place, with the fallback notes
├── gradle/wrapper/…, gradlew*     Gradle wrapper pinned to 9.5.0
└── app/
    ├── build.gradle.kts           Android config: API 31 to 37, Compose, Hilt (KSP), dependencies
    ├── proguard-rules.pro         R8 rules for release
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml     No permissions, backup off, one activity
        │   ├── assets/licenses/        The three font licences (OFL)
        │   ├── res/                    Strings, themes, night colours, fonts, vector icons, launcher icon
        │   └── java/com/onlyus/app/
        ├── test/                       The 47 unit tests
```

**App shell** (`com/onlyus/app`)

| File | Job |
|---|---|
| `OnlyUsApplication.kt` | `@HiltAndroidApp` entry point |
| `MainActivity.kt` | Edge-to-edge window; shows the app once saved settings have loaded |
| `MainViewModel.kt` | Combines saved preferences with device facts into the theme and effects the UI uses |
| `ui/OnlyUsApp.kt` | Applies the theme, the shared background and the status/navigation bar icon colours |
| `navigation/Destinations.kt`, `OnlyUsNavHost.kt` | Route names; the three routes (splash, onboarding, gallery) and the transitions |

**Core** (`core/`)

| File | Job |
|---|---|
| `preferences/AppPreferences.kt` | Theme choice, effects choice and "onboarding done", saved in DataStore |
| `device/DeviceCapabilities.kt` | Low-RAM, Battery Saver and animation-scale facts, as a Flow that updates live |
| `di/AppModule.kt` | Hilt provider for the DataStore |

**Design system** (`core/designsystem/theme`)

| File | Job |
|---|---|
| `Color.kt` | The palette and the light and dark Material 3 colour schemes |
| `GlassTokens.kt` | Glass and brand colours (gradients, action button, hearts, status colours) for both themes |
| `Type.kt` | Fonts and the whole type scale |
| `Dimens.kt` | Spacing, radius, shapes and motion timings |
| `Effects.kt` | Effects modes and the single rule that resolves them (unit-tested) |
| `ThemeTransition.kt`, `Theme.kt` | The animated light/dark blend and `OnlyUsTheme` itself |

**Design system** (`core/designsystem/components`): the components listed in section 5, plus `Initials.kt` (the
avatar-letters function, kept pure so it can be unit-tested) and `GlassSurface.kt` (the glass recipe).

**Features**

| File | Job |
|---|---|
| `features/splash/SplashTimeline.kt` | The choreography as plain numbers: windows, easing, the seven hearts (unit-tested) |
| `features/splash/SplashScreen.kt`, `SplashViewModel.kt` | The screen, and the decision of where to go next |
| `features/onboarding/OnboardingScreen.kt`, `OnboardingViewModel.kt` | The three pages; saving "done" before leaving |
| `features/showcase/…` | The gallery: screen, view model, three section files, and `ShowcasePreviews.kt` for Studio |

**Tests** (`app/src/test`): `EffectsPolicyTest`, `SplashTimelineTest`, `InitialsTest`.

---

## 7. Accessibility and performance decisions

**Accessibility**
- Text contrast is designed and audited (section 8). Body text at least 7:1, secondary text at least 4.5:1,
  borders and indicators at least 3:1.
- Every tappable thing is at least 48 dp. Icon buttons must be given a content description.
- Nav items are announced as tabs, choice chips as a radio group, badges as "N unread notifications", field errors
  as errors, headings as headings. Decorative art is hidden from screen readers.
- Nothing depends on colour alone: errors and successes are also written out.
- Motion respects the system animation setting; the logo ignores font scale so it never clips.

**Performance**
- No real-time blur. Glass is translucency, a border and a shadow.
- No infinite animation except the loading heart, and only while loading.
- Animation values are read while drawing, so animated pieces redraw without recomposing.
- Reduced-effects mode removes shadows, sheen, glows and floating hearts.
- Dependencies are the minimum for the brief: Compose, AndroidX core, lifecycle, navigation, DataStore, coroutines
  and Hilt, plus the standard Compose preview tooling (used by `ShowcasePreviews.kt`). No icon library (icons are
  small vector drawables) and no splash library.

**Privacy and security (this phase)**
- No permissions, no network access, no Firebase, no analytics. Backup is off.
- Nothing is stored except three settings on the phone.

---

## 8. Verification report

| Check | How | Result | What it does **not** prove |
|---|---|---|---|
| Kotlin syntax | tree-sitter Kotlin grammar over all 45 files | 0 syntax errors | Not a type check: wrong names or types would not show |
| Resources | 28 XML files well-formed; every `R.string`, plural, drawable and font used in code exists | OK (151 strings, 1 plural, 22 drawables, 6 fonts). Two spare icons (`ic_arrow_back`, `ic_close`) are unused on purpose | Not the Android resource compiler |
| Imports | 599 `androidx` imports checked against AndroidX's public API listings (`api/current.txt`, downloaded 13 Nov); also 0 missing and 0 unused imports in the whole project | 0 unresolved | The listings follow the AndroidX repository, not necessarily the exact pinned versions. This catches wrong names and packages, not every possible mismatch |
| Colour contrast | A script reads the real colours from the Kotlin files and checks 82 text, control and outline pairs (WCAG 2.x), modelling glass over the gradients at its worst case | All 82 pass | A model, not a screenshot measurement |
| Unit tests | 47 JUnit tests: the effects rule across 3 modes × 8 device states, the splash timeline and hearts, avatar initials. Compiled with the Kotlin compiler that ships inside Gradle (2.0.21, **not** the project's 2.4.21) and run on the real JUnit 4.13.2 | 47 of 47 pass, no compiler warnings | Only plain-Kotlin logic. No Compose UI is covered |
| Test strength | 20 deliberate bugs (inverted rules, removed clamps, swapped constants, the old naive initials) injected one at a time | All 20 caught by at least one test | — |
| **Real Gradle build** | Attempted | **Not possible in my sandbox** (hosts blocked, HTTP 403) | **This is the check that matters most, and it is yours to run** |

Version choices (Android Gradle Plugin 9.3.3, Gradle 9.5.0, Kotlin 2.4.21, KSP 2.3.13, Hilt 2.60.1, Compose BOM
2026.09.00) were taken from the official release notes on 12 Nov 2026 and are noted in `gradle/libs.versions.toml`.
They have not been through a successful sync yet.

---

## 9. Decisions you may want to change

1. **Minimum Android version.** Your Phase 1 brief says Android 12 (API 31); the master prompt says Android 8.0+. I
   followed the Phase 1 brief. Lowering it later is possible but means handling the system splash differently below 12.
2. **Application ID** is `com.onlyus.app`. Change it **now** if you want a different one: Firebase (Phase 3) is
   registered against it.
3. **Target SDK** is 35 (Android 15). Raise it to Google's current requirement before a Play Store release (Phase 10).
   It does not affect which phones can run the app.
4. **The gallery is the temporary home screen** after onboarding, so you can see and test the design system. Phase 2
   replaces it with the real Home.
5. **Onboarding mentions things not built yet** (voice notes, photos, countdowns, letters), because they are the plan.
   Edit the three pages in `strings.xml` if you would rather say less until they exist.
6. **The palette follows your Stage 4 brief**, so the Phase 1 "Soft Lavender" is no longer used.
7. **Placeholder content.** The gallery's names (Sam Rivera, Jordan Lee) and quotes are generic samples. Nothing about
   you or your girlfriend is invented.
8. **A framework note.** The value-based Material 3 text field is marked deprecated in newer releases (a warning, not
   an error). It is suppressed in exactly one place, `TextFields.kt`, and can move to the newer state-based field later.

---

## 10. What comes next

Nothing yet. Per your rule, Stage 5 (Phase 2: Home screen, navigation and the glass components in real screens) does
not begin until Stage 4 builds and runs on your side. Firebase integration starts at Phase 3 and not before.
